#include "ViewportSilent.h"

#include "../../Globals/Globals.h"
#include "../../Memory/Memory.h"
#include "../../Roblox/Engine/Offsets/Offsets.h"
#include "../../Roblox/Engine/Classes/Classes.h"
#include "../../../Renderer/Renderer.h"

#include <Windows.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>

namespace Cheat {
namespace Features {
namespace ViewportSilent {
namespace {

struct Vec2i16 {
    std::int16_t x = 0;
    std::int16_t y = 0;
};

std::atomic<bool>  g_active{ false };
std::atomic<bool>  g_stop{ false };
std::atomic<bool>  g_spoofed{ false };
std::atomic<float> g_tx{ 0.f }, g_ty{ 0.f }, g_tz{ 0.f };

HANDLE        g_thread = nullptr;
std::uint64_t g_cam = 0;
Vector2       g_dims{};
Vec2i16       g_last{};
int           g_fails = 0;

uintptr_t VisualEngine()
{
    static uintptr_t base = 0;
    if (!base) base = g_Memory.GetModuleBase();
    if (!base) return 0;
    const uintptr_t ve = g_Memory.Read<uintptr_t>(base + Offsets::VisualEngine::Pointer);
    return g_Memory.IsValid(ve) ? ve : 0;
}

Vector2 WorldToScreen(const Vector3& pos, Vector2& dims_out)
{
    const uintptr_t ve = VisualEngine();
    if (!ve) return {};

    float view[16]{};
    if (g_Memory.ReadRaw(ve + Offsets::VisualEngine::ViewMatrix, view, sizeof(view)) != sizeof(view))
        return {};

    dims_out = g_Memory.Read<Vector2>(ve + Offsets::VisualEngine::Dimensions);
    if (dims_out.x < 1.f || dims_out.y < 1.f)
        return {};

    float x = pos.x * view[0] + pos.y * view[1] + pos.z * view[2] + view[3];
    float y = pos.x * view[4] + pos.y * view[5] + pos.z * view[6] + view[7];
    float w = pos.x * view[12] + pos.y * view[13] + pos.z * view[14] + view[15];
    if (w < 0.001f) return {};

    const float inv = 1.0f / w;
    x *= inv;
    y *= inv;

    return {
        (dims_out.x * 0.5f) * (1.0f + x),
        (dims_out.y * 0.5f) * (1.0f - y)
    };
}

Vec2i16 CalcViewport(const Vector2& target, const Vector2& dims, const Vector2& mouse)
{
    double ty = (std::max)(1.0, (std::min)((double)target.y, (double)dims.y - 1.0));
    double ratio = (double)mouse.y / ty;
    double vy = (std::max)(1.0, (std::min)((double)dims.y * ratio, 32767.0));
    ratio = vy / (double)dims.y;
    double vx = 2.0 * (double)mouse.x - ratio * (2.0 * (double)target.x - (double)dims.x);
    vx = (std::max)(1.0, (std::min)(vx, 32767.0));
    return { (std::int16_t)std::lround(vx), (std::int16_t)std::lround(vy) };
}

bool MouseInViewport(const Vector2& dims, Vector2& out)
{
    HWND hwnd = Renderer::GetGameHwnd();
    if (!hwnd || !IsWindow(hwnd))
        return false;

    POINT pt{};
    if (!GetCursorPos(&pt) || !ScreenToClient(hwnd, &pt))
        return false;

    RECT cr{};
    if (!GetClientRect(hwnd, &cr))
        return false;

    const float cw = (float)(cr.right - cr.left);
    const float ch = (float)(cr.bottom - cr.top);
    if (cw < 1.f || ch < 1.f)
        return false;
    if (pt.x < 0 || pt.y < 0 || pt.x >= cr.right || pt.y >= cr.bottom)
        return false;

    out.x = (std::max)(1.f, (std::min)((float)pt.x * (dims.x / cw), dims.x - 1.f));
    out.y = (std::max)(1.f, (std::min)((float)pt.y * (dims.y / ch), dims.y - 1.f));
    return true;
}

bool ResolveCam(std::uint64_t& cam)
{
    if (!Globals::Workspace) return false;
    auto c = Globals::Workspace->GetCurrentCamera();
    if (!c || !g_Memory.IsValid(c->address)) return false;
    cam = c->address;
    return true;
}

void WriteViewport(const Vec2i16& v)
{
    if (!g_Memory.IsValid(g_cam)) return;
    g_Memory.WriteRaw(g_cam + Offsets::Camera::Viewport, &v, sizeof(v));
    g_spoofed.store(true, std::memory_order_release);
}

void RestoreViewport()
{
    if (!g_Memory.IsValid(g_cam) || g_dims.x < 1.f || g_dims.y < 1.f)
        return;
    const Vec2i16 v{
        (std::int16_t)std::lround(g_dims.x),
        (std::int16_t)std::lround(g_dims.y)
    };
    g_Memory.WriteRaw(g_cam + Offsets::Camera::Viewport, &v, sizeof(v));
}

bool Compute(Vec2i16& out)
{
    const Vector3 world{
        g_tx.load(std::memory_order_relaxed),
        g_ty.load(std::memory_order_relaxed),
        g_tz.load(std::memory_order_relaxed)
    };

    std::uint64_t cam = 0;
    if (!ResolveCam(cam)) return false;

    Vector2 dims{};
    const Vector2 w2s = WorldToScreen(world, dims);
    if (w2s.x <= 0.f || w2s.y <= 0.f || w2s.x >= dims.x || w2s.y >= dims.y)
        return false;

    Vector2 mouse{};
    if (!MouseInViewport(dims, mouse))
        return false;

    out = CalcViewport(w2s, dims, mouse);
    g_cam = cam;
    g_dims = dims;
    return true;
}

DWORD WINAPI Writer(LPVOID)
{
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
    bool on = false;

    while (!g_stop.load(std::memory_order_acquire)) {
        if (!g_active.load(std::memory_order_acquire)) {
            if (on) {
                RestoreViewport();
                g_spoofed.store(false, std::memory_order_release);
                g_fails = 0;
                on = false;
            }
            Sleep(16);
            continue;
        }

        Vec2i16 v{};
        if (Compute(v)) {
            g_last = v;
            g_fails = 0;
            on = true;
            WriteViewport(g_last);
        } else if (on && g_fails < 40) {
            ++g_fails;
            WriteViewport(g_last);
        } else if (on) {
            RestoreViewport();
            g_spoofed.store(false, std::memory_order_release);
            on = false;
            g_fails = 0;
        }

        Sleep(1);
    }

    RestoreViewport();
    g_spoofed.store(false, std::memory_order_release);
    return 0;
}

void EnsureThread()
{
    if (g_thread) return;
    g_stop.store(false, std::memory_order_release);
    g_thread = CreateThread(nullptr, 0, &Writer, nullptr, 0, nullptr);
    if (g_thread)
        SetThreadPriority(g_thread, THREAD_PRIORITY_HIGHEST);
}

} // namespace

void Restore()
{
    g_active.store(false, std::memory_order_release);
    RestoreViewport();
    g_spoofed.store(false, std::memory_order_release);
}

void SetActive(bool on, const Vector3& world_target)
{
    if (!on) {
        Restore();
        return;
    }
    EnsureThread();
    g_tx.store(world_target.x, std::memory_order_relaxed);
    g_ty.store(world_target.y, std::memory_order_relaxed);
    g_tz.store(world_target.z, std::memory_order_relaxed);
    g_active.store(true, std::memory_order_release);
}

void Shutdown()
{
    g_active.store(false, std::memory_order_release);
    if (!g_thread) return;
    g_stop.store(true, std::memory_order_release);
    WaitForSingleObject(g_thread, 1000);
    CloseHandle(g_thread);
    g_thread = nullptr;
    g_cam = 0;
    g_dims = {};
}

bool Aiming()
{
    return g_active.load(std::memory_order_acquire) &&
           g_spoofed.load(std::memory_order_acquire);
}

} // namespace ViewportSilent
} // namespace Features
} // namespace Cheat
