#include "MouseSilent.h"

#include "../../Globals/Globals.h"
#include "../../Memory/Memory.h"
#include "../../Roblox/Engine/Offsets/Offsets.h"
#include "../../Roblox/Engine/Classes/Classes.h"

#include <cstdint>

namespace Cheat {
namespace Features {
namespace MouseSilent {
namespace {

bool          g_aiming = false;
std::uint64_t g_mouse_service = 0;

bool WorldToScreen(const Matrix4x4& m, const Vector2& dim, const Vector3& p, Vector2& out)
{
    const float w = p.x * m.m[3][0] + p.y * m.m[3][1] + p.z * m.m[3][2] + m.m[3][3];
    if (w < 0.01f) return false;
    const float x = p.x * m.m[0][0] + p.y * m.m[0][1] + p.z * m.m[0][2] + m.m[0][3];
    const float y = p.x * m.m[1][0] + p.y * m.m[1][1] + p.z * m.m[1][2] + m.m[1][3];
    const float inv = 1.0f / w;
    out.x = (dim.x * 0.5f) + (x * inv * dim.x * 0.5f);
    out.y = (dim.y * 0.5f) - (y * inv * dim.y * 0.5f);
    return true;
}

std::uint64_t ResolveMouseService()
{
    if (g_mouse_service && g_Memory.IsValid(g_mouse_service))
        return g_mouse_service;

    if (!Globals::InstanceDataModel.address ||
        !g_Memory.IsValid(Globals::InstanceDataModel.address))
        return 0;

    auto ms = Instance(Globals::InstanceDataModel.address).FindFirstChild("MouseService");
    if (!ms || !g_Memory.IsValid(ms->address))
        return 0;

    g_mouse_service = ms->address;
    return g_mouse_service;
}

bool WriteMousePos(std::uint64_t mouse_service, float x, float y)
{
    auto try_input = [&](std::uintptr_t input_off) -> bool {
        const std::uint64_t input =
            g_Memory.Read<std::uint64_t>(mouse_service + input_off);
        if (!input || input == static_cast<std::uint64_t>(-1) || !g_Memory.IsValid(input))
            return false;
        const float pos[2]{ x, y };
        return g_Memory.WriteRaw(
                   input + Offsets::MouseService::MousePosition, pos, sizeof(pos)) == sizeof(pos);
    };

    if (try_input(Offsets::MouseService::InputObject2))
        return true;
    return try_input(Offsets::MouseService::InputObject);
}

bool ResolveView(Matrix4x4& out_view, Vector2& out_dims)
{
    if (!Globals::Workspace)
        return false;

    auto cam_ptr = Globals::Workspace->GetCurrentCamera();
    if (!cam_ptr || !g_Memory.IsValid(cam_ptr->address))
        return false;

    Camera cam(cam_ptr->address);
    out_dims = cam.GetViewportSize();
    if (out_dims.x < 1.f || out_dims.y < 1.f)
        return false;

    static uintptr_t base = 0;
    if (!base) base = g_Memory.GetModuleBase();
    if (!base) return false;

    const uintptr_t ve = g_Memory.Read<uintptr_t>(base + Offsets::VisualEngine::Pointer);
    if (!g_Memory.IsValid(ve))
        return false;

    out_view = g_Memory.Read<Matrix4x4>(ve + Offsets::VisualEngine::ViewMatrix);
    return true;
}

} // namespace

void Restore()
{
    g_aiming = false;
}

void SetActive(bool on, const Vector3& world_target)
{
    if (!on) {
        Restore();
        return;
    }

    const std::uint64_t ms = ResolveMouseService();
    if (!ms)
        return;

    Matrix4x4 view{};
    Vector2 dims{};
    if (!ResolveView(view, dims))
        return;

    Vector2 target{};
    if (!WorldToScreen(view, dims, world_target, target))
        return;

    if (!WriteMousePos(ms, target.x, target.y)) {
        g_mouse_service = 0; // force re-resolve next frame
        return;
    }

    g_aiming = true;
}

bool Aiming()
{
    return g_aiming;
}

} // namespace MouseSilent
} // namespace Features
} // namespace Cheat
