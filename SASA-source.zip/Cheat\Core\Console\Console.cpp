#define NOMINMAX
#include "Console.h"
#include "../Globals/Globals.h"
#include "../Memory/Memory.h"
#include "../Roblox/Engine/Offsets/Offsets.h"
#include "../PlayerHandler/PlayerHandler.h"
#include <Windows.h>
#include <cstdio>
#include <cstdarg>
#include <cstdint>
#include <mutex>

namespace Cheat::Console {
namespace {

std::mutex g_mu;
bool g_vt = false;
bool g_have_last_crash = false;
unsigned long g_last_crash_code = 0;

void ensure_console()
{
    static bool once = false;
    if (once) return;
    once = true;
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!h || h == INVALID_HANDLE_VALUE) return;
    DWORD mode = 0;
    if (GetConsoleMode(h, &mode)) {
        mode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
        g_vt = SetConsoleMode(h, mode) != 0;
    }
}

void stamp(char* out, size_t n)
{
    SYSTEMTIME st{};
    GetLocalTime(&st);
    std::snprintf(out, n, "[%02u:%02u:%02u]",
        (unsigned)st.wHour, (unsigned)st.wMinute, (unsigned)st.wSecond);
}

WORD attr(Color c)
{
    return static_cast<WORD>(c);
}

void write_colored(Color color, const char* text)
{
    ensure_console();
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    if (h && h != INVALID_HANDLE_VALUE) {
        CONSOLE_SCREEN_BUFFER_INFO csbi{};
        GetConsoleScreenBufferInfo(h, &csbi);
        SetConsoleTextAttribute(h, attr(color));
        std::fputs(text, stdout);
        SetConsoleTextAttribute(h, csbi.wAttributes);
    } else {
        std::fputs(text, stdout);
    }
}

void log_locked(Color color, const char* body)
{
    char t[16]{};
    stamp(t, sizeof(t));
    write_colored(Color::Dim, t);
    write_colored(Color::Dim, ": ");
    write_colored(color, body);
    std::fputc('\n', stdout);
    std::fflush(stdout);
}

enum class CrashSide {
    User,
    Cheat,
    Both,
    Info
};

struct CrashInfo {
    const char* name;
    CrashSide side;
    const char* fix;
    const char* dev;
};

CrashInfo classify_crash(unsigned long code)
{
    switch (code) {
    case 0:
        return {
            "Clean Exit",
            CrashSide::Info,
            "Roblox closed normally (not a crash).",
            nullptr
        };
    case 0xC000013A:
        return {
            "Process Terminated",
            CrashSide::User,
            "Roblox was closed from Task Manager / killed by another app. Just reopen the game.",
            nullptr
        };
    case 0xC0000135:
        return {
            "DLL Not Found",
            CrashSide::User,
            "Missing system/Roblox DLL. Reinstall Roblox and install latest VC++ Redistributable (x64).",
            nullptr
        };
    case 0xC0000142:
        return {
            "DLL Init Failed",
            CrashSide::User,
            "A DLL failed to load. Update GPU drivers, reinstall VC++ Redistributable, then reinstall Roblox.",
            nullptr
        };
    case 0xC000007B:
        return {
            "Bad Image",
            CrashSide::User,
            "Corrupted Roblox install. Delete %localappdata%\\Roblox and reinstall.",
            nullptr
        };
    case 0xC0000017:
    case 0xC000009A:
        return {
            "Out Of Memory",
            CrashSide::User,
            "Not enough RAM/VRAM. Close other apps, lower Roblox graphics, reboot PC.",
            nullptr
        };
    case 0xC0000006:
        return {
            "In-Page Error",
            CrashSide::User,
            "Disk/RAM read failed. Check disk health, free space, run Windows Memory Diagnostic.",
            nullptr
        };
    case 0xC0000185:
        return {
            "IO Device Error",
            CrashSide::User,
            "Storage/device error while loading assets. Check disk, disable overlays, reinstall Roblox.",
            nullptr
        };
    case 0xE06D7363:
        return {
            "C++ Exception",
            CrashSide::User,
            "Roblox threw an internal exception (often bad update/install). Full reinstall Roblox usually fixes it.",
            "If it happens only with cheat features on, note which feature was enabled."
        };
    case 0xC0000005:
        return {
            "Access Violation",
            CrashSide::Both,
            "Update GPU drivers, disable overlays (Discord/MSI/GeForce), then reinstall Roblox if it keeps happening.",
            "Often cheat-side too: bad read/write or silent hook. Disable silent/fly/speed and retry."
        };
    case 0xC0000374:
        return {
            "Heap Corruption",
            CrashSide::Cheat,
            "If it still happens with all features off, reinstall Roblox. Otherwise this is usually the cheat.",
            "Likely invalid memory write (fly/speed/silent/noclip). Bisect features; check offsets."
        };
    case 0xC0000409:
        return {
            "Stack Buffer Overrun",
            CrashSide::Cheat,
            "Rarely a broken Roblox install — try reinstall if features are all off.",
            "Usually hook/stack smash (silent inject). Disable silent, verify stub/handler."
        };
    case 0xC00000FD:
        return {
            "Stack Overflow",
            CrashSide::Cheat,
            "Reboot and reopen Roblox. If clean (no cheat features) still crashes, reinstall Roblox.",
            "Possible infinite recursion from hook/callback. Check silent path."
        };
    case 0xC000001D:
        return {
            "Illegal Instruction",
            CrashSide::Both,
            "CPU/feature mismatch or corrupted binary. Reinstall Roblox; update Windows.",
            "Possible bad patched code bytes in silent stub."
        };
    case 0xC0000096:
        return {
            "Privileged Instruction",
            CrashSide::Cheat,
            "Unlikely user-fixable unless antivirus is injecting. Add exclusions and retry.",
            "Bad code patch / wrong RVA executed."
        };
    case 0xC000041D:
        return {
            "Fatal Callback Exception",
            CrashSide::Both,
            "Restart PC, update GPU drivers, disable overlays, reinstall Roblox.",
            "Can be triggered by hooks during window/input callbacks."
        };
    default:
        break;
    }

    if ((code & 0xF0000000u) == 0xC0000000u) {
        return {
            "NTSTATUS Crash",
            CrashSide::Both,
            "Unknown Windows crash. Reinstall Roblox, update GPU drivers, disable overlays/antivirus briefly.",
            "Log this code and which features were enabled."
        };
    }

    return {
        "Unknown Exit",
        CrashSide::Both,
        "Roblox exited with an uncommon code. Reopen game; if repeatable, reinstall Roblox.",
        "Save exit code + active features for debugging."
    };
}

const char* side_text(CrashSide side)
{
    switch (side) {
    case CrashSide::User:  return "user (fixable)";
    case CrashSide::Cheat: return "cheat (dev)";
    case CrashSide::Both:  return "user + cheat";
    case CrashSide::Info:  return "info";
    }
    return "unknown";
}

void dump_crash_locked(unsigned long exit_code)
{
    const CrashInfo info = classify_crash(exit_code);
    const long long signed_code = static_cast<long long>(static_cast<std::int32_t>(exit_code));

    log_locked(Color::White, "SASA crash");
    {
        char body[160]{};
        std::snprintf(body, sizeof(body), "Exit code      0x%08lX (%lld)",
            exit_code, signed_code);
        log_locked(Color::Yellow, body);
    }
    {
        char body[160]{};
        std::snprintf(body, sizeof(body), "Name           %s", info.name);
        log_locked(Color::Orange, body);
    }
    {
        char body[160]{};
        std::snprintf(body, sizeof(body), "Side           %s", side_text(info.side));
        const Color c = (info.side == CrashSide::Cheat) ? Color::Red
            : (info.side == CrashSide::User) ? Color::Green
            : (info.side == CrashSide::Info) ? Color::Gray
            : Color::Magenta;
        log_locked(c, body);
    }
    if (info.fix && info.fix[0]) {
        char body[640]{};
        std::snprintf(body, sizeof(body), "Fix            %s", info.fix);
        log_locked(Color::Lime, body);
    }
    if (info.dev && info.dev[0]) {
        char body[640]{};
        std::snprintf(body, sizeof(body), "Dev            %s", info.dev);
        log_locked(Color::Cyan, body);
    }
}

} // namespace

void Clear()
{
    std::lock_guard<std::mutex> lock(g_mu);
    ensure_console();
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!h || h == INVALID_HANDLE_VALUE) return;

    CONSOLE_SCREEN_BUFFER_INFO csbi{};
    if (!GetConsoleScreenBufferInfo(h, &csbi)) return;

    const DWORD cells = (DWORD)csbi.dwSize.X * (DWORD)csbi.dwSize.Y;
    DWORD written = 0;
    COORD home{ 0, 0 };
    FillConsoleOutputCharacterA(h, ' ', cells, home, &written);
    FillConsoleOutputAttribute(h, csbi.wAttributes, cells, home, &written);
    SetConsoleCursorPosition(h, home);
}

void Log(Color color, const char* fmt, ...)
{
    if (!fmt) return;
    char body[640]{};
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(body, sizeof(body), fmt, ap);
    va_end(ap);
    std::lock_guard<std::mutex> lock(g_mu);
    log_locked(color, body);
}

void Log(const char* fmt, ...)
{
    if (!fmt) return;
    char body[640]{};
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(body, sizeof(body), fmt, ap);
    va_end(ap);
    std::lock_guard<std::mutex> lock(g_mu);
    log_locked(Color::White, body);
}

void Ptr(Color color, const char* name, std::uint64_t addr)
{
    Log(color, "%-14s 0x%llX", name ? name : "?", (unsigned long long)addr);
}

void Ptr(const char* name, std::uint64_t addr)
{
    Ptr(Color::Cyan, name, addr);
}

void DumpCrash(unsigned long exit_code)
{
    std::lock_guard<std::mutex> lock(g_mu);
    g_have_last_crash = true;
    g_last_crash_code = exit_code;
    dump_crash_locked(exit_code);
}

void DumpLastCrash()
{
    std::lock_guard<std::mutex> lock(g_mu);
    if (!g_have_last_crash)
        return;
    dump_crash_locked(g_last_crash_code);
}

void DumpWorld()
{
    const uintptr_t base = g_Memory.GetModuleBase();
    const DWORD pid = g_Memory.GetPID();
    const std::uint64_t ve = base
        ? g_Memory.Read<std::uint64_t>(base + Offsets::VisualEngine::Pointer) : 0;
    const std::uint64_t front = Globals::FrontDataModel;
    const std::uint64_t dm = Globals::InstanceDataModel.address;
    const std::uint64_t ws = Globals::Workspace ? Globals::Workspace->address : 0;
    const std::uint64_t pl = Globals::Players ? Globals::Players->address : 0;

    std::uint64_t local_player = 0;
    std::uint64_t local_char = 0;
    std::uint64_t camera = 0;
    std::int64_t place_id = 0;
    std::int64_t game_id = 0;
    std::int64_t user_id = 0;
    std::uint64_t world = 0;

    if (dm) {
        place_id = g_Memory.Read<std::int64_t>(dm + Offsets::DataModel::PlaceId);
        game_id  = g_Memory.Read<std::int64_t>(dm + Offsets::DataModel::GameId);
    }
    if (pl) {
        local_player = g_Memory.Read<std::uint64_t>(pl + Offsets::Player::LocalPlayer);
        if (g_Memory.IsValid(local_player)) {
            local_char = g_Memory.Read<std::uint64_t>(
                local_player + Offsets::Player::ModelInstance);
            user_id = g_Memory.Read<std::int64_t>(
                local_player + Offsets::Player::UserId);
        }
    }
    if (ws) {
        camera = g_Memory.Read<std::uint64_t>(ws + Offsets::Workspace::CurrentCamera);
        world  = g_Memory.Read<std::uint64_t>(ws + Offsets::Workspace::World);
    }

    const std::size_t players = PlayerHandler::GetPlayerCount();

    Log(Color::White,   "SASA status");
    Log(Color::Gray,    "PID            %lu", (unsigned long)pid);
    Ptr(Color::Cyan,    "Module", base);
    Ptr(Color::Yellow,  "Front DM", front);
    Ptr(Color::Green,   "Data Model", dm);
    Ptr(Color::Magenta, "Render View", ve);
    Ptr(Color::Blue,    "Workspace", ws);
    Ptr(Color::Teal,    "World", world);
    Ptr(Color::Sky,     "Players", pl);
    Ptr(Color::Lime,    "LocalPlayer", local_player);
    Ptr(Color::Purple,  "Character", local_char);
    Ptr(Color::Pink,    "Camera", camera);
    Log(Color::Orange,  "PlaceId        %lld", (long long)place_id);
    Log(Color::Yellow,  "GameId         %lld", (long long)game_id);
    Log(Color::Lime,    "UserId         %lld", (long long)user_id);
    Log(Color::White,   "Cached         %zu players", players);

    bool have_crash = false;
    unsigned long crash_code = 0;
    {
        std::lock_guard<std::mutex> lock(g_mu);
        have_crash = g_have_last_crash;
        crash_code = g_last_crash_code;
    }
    if (have_crash) {
        const CrashInfo info = classify_crash(crash_code);
        Log(Color::Red, "Last crash     0x%08lX  %s  [%s]",
            crash_code, info.name, side_text(info.side));
    }
}

void DumpSilent(bool ok, std::uint64_t handler, std::uint64_t stub,
                std::uint64_t state, std::uint64_t slot, const char* detail)
{
    if (ok) {
        Log(Color::Green, "Silent inject  ok");
        Ptr(Color::Magenta, "Handler", handler);
        Ptr(Color::Yellow,  "Stub", stub);
        Ptr(Color::Cyan,    "State", state);
        Ptr(Color::Blue,    "Slot", slot);
        Ptr(Color::Teal,    "Desc RVA", Offsets::WorldRoot::RaycastBoundDesc);
        Log(Color::Gray,    "Fn off         0x%llX",
            (unsigned long long)Offsets::WorldRoot::RaycastBoundFn);
    } else {
        Log(Color::Red, "Silent inject  fail%s%s",
            detail && detail[0] ? " " : "",
            detail ? detail : "");
        if (handler) Ptr(Color::Magenta, "Handler", handler);
        if (stub)    Ptr(Color::Yellow,  "Stub", stub);
        if (slot)    Ptr(Color::Blue,    "Slot", slot);
    }
}

} // namespace Cheat::Console
