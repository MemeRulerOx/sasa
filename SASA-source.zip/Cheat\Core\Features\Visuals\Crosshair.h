#pragma once

namespace Cheat {
namespace Visuals {
namespace Crosshair {

    void Render();
    void NotifyInactive(); // roblox unfocused — restore OS cursor, keep thread
    void Shutdown();       // full teardown + restore Windows cursor

} // namespace Crosshair
} // namespace Visuals
} // namespace Cheat
