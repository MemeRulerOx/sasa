#include "RaycastEngine.h"

#include "../../Globals/Globals.h"
#include "../../Memory/Memory.h"
#include "../../Roblox/Engine/Offsets/Offsets.h"
#include "../../Roblox/Engine/Classes/Classes.h"
#include "../../../Settings.h"

#undef GetClassName

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <climits>
#include <limits>
#include <memory>
#include <mutex>
#include <optional>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace Cheat::Features::RaycastEngine {
namespace {

using clock = std::chrono::steady_clock;

struct float3x3 {
    float _11{}, _12{}, _13{};
    float _21{}, _22{}, _23{};
    float _31{}, _32{}, _33{};
};

struct occluder_part {
    std::uint64_t primitive = 0;
    Vector3 position{};
    Vector3 half_size{};
    float3x3 rotation{};
    float radius_sq = 0.0f;
    mutable std::atomic<std::uint64_t> last_query_id{ 0 };

    occluder_part() = default;
    occluder_part(const occluder_part& o)
        : primitive(o.primitive), position(o.position), half_size(o.half_size),
          rotation(o.rotation), radius_sq(o.radius_sq) {
        last_query_id.store(o.last_query_id.load(std::memory_order_relaxed), std::memory_order_relaxed);
    }
    occluder_part& operator=(const occluder_part& o) {
        if (this != &o) {
            primitive = o.primitive; position = o.position; half_size = o.half_size;
            rotation = o.rotation; radius_sq = o.radius_sq;
            last_query_id.store(o.last_query_id.load(std::memory_order_relaxed), std::memory_order_relaxed);
        }
        return *this;
    }
    occluder_part(occluder_part&& o) noexcept
        : primitive(o.primitive), position(o.position), half_size(o.half_size),
          rotation(o.rotation), radius_sq(o.radius_sq) {
        last_query_id.store(o.last_query_id.load(std::memory_order_relaxed), std::memory_order_relaxed);
    }
    occluder_part& operator=(occluder_part&& o) noexcept {
        if (this != &o) {
            primitive = o.primitive; position = o.position; half_size = o.half_size;
            rotation = o.rotation; radius_sq = o.radius_sq;
            last_query_id.store(o.last_query_id.load(std::memory_order_relaxed), std::memory_order_relaxed);
        }
        return *this;
    }
};

struct cell_key {
    int x = 0, y = 0, z = 0;
    bool operator==(const cell_key& o) const { return x == o.x && y == o.y && z == o.z; }
};

struct cell_key_hash {
    std::size_t operator()(const cell_key& k) const noexcept {
        std::size_t h = 0;
        auto combine = [&](std::size_t v) { h ^= v + 0x9e3779b9 + (h << 6) + (h >> 2); };
        combine(std::hash<int>{}(k.x));
        combine(std::hash<int>{}(k.y));
        combine(std::hash<int>{}(k.z));
        return h;
    }
};

struct occluder_cache {
    std::vector<occluder_part> parts;
    std::unordered_map<cell_key, std::vector<std::uint32_t>, cell_key_hash> grid;
    float cell_size = 32.0f;
    bool complete = false;
    double build_time = 0.0;
};

struct occluder_builder {
    std::uint64_t primitives_base = 0;
    std::size_t cursor = 0;
    std::size_t max_scan = 0;
    bool active = false;
    bool complete = false;
    double last_step = 0.0;
    std::size_t consecutive_null_slots = 0;
    bool found_non_null_slot = false;
    occluder_cache building_cache;
    std::unordered_set<std::uint64_t> ignore_primitives;

    void reset() {
        *this = occluder_builder{};
    }

    void start(std::uint64_t base, std::unordered_set<std::uint64_t>&& ignore,
               float cell_size, std::size_t max_scan_count) {
        primitives_base = base;
        cursor = 0;
        max_scan = max_scan_count;
        active = base != 0 && max_scan_count > 0;
        complete = !active;
        last_step = 0.0;
        consecutive_null_slots = 0;
        found_non_null_slot = false;
        building_cache = occluder_cache{};
        building_cache.cell_size = cell_size;
        ignore_primitives = std::move(ignore);
        if (active)
            building_cache.parts.reserve((std::min)(max_scan_count, std::size_t{ 131072 }));
    }
};

double now_sec() {
    return std::chrono::duration<double>(clock::now().time_since_epoch()).count();
}

Vector3 multiply_transpose(const float3x3& m, const Vector3& v) {
    return Vector3(
        m._11 * v.x + m._12 * v.y + m._13 * v.z,
        m._21 * v.x + m._22 * v.y + m._23 * v.z,
        m._31 * v.x + m._32 * v.y + m._33 * v.z);
}

float component(const Vector3& v, int axis) {
    return axis == 0 ? v.x : (axis == 1 ? v.y : v.z);
}

float3x3 identity_rotation() {
    float3x3 r{};
    r._11 = r._22 = r._33 = 1.0f;
    return r;
}

std::optional<float3x3> read_rotation(std::uint64_t prim) {
    if (!prim) return std::nullopt;
    float3x3 rot{};
    g_Memory.ReadRaw(prim + Offsets::Primitive::Rotation, &rot, sizeof(rot));
    const float* values = reinterpret_cast<const float*>(&rot);
    for (int i = 0; i < 9; ++i) {
        if (!std::isfinite(values[i]))
            return std::nullopt;
    }
    return rot;
}

std::optional<Vector3> read_position(std::uint64_t prim) {
    if (!prim) return std::nullopt;
    const Vector3 pos = g_Memory.Read<Vector3>(prim + Offsets::Primitive::Position);
    if (!std::isfinite(pos.x) || !std::isfinite(pos.y) || !std::isfinite(pos.z))
        return std::nullopt;
    return pos;
}

std::optional<Vector3> read_size(std::uint64_t prim) {
    if (!prim) return std::nullopt;
    const Vector3 size = g_Memory.Read<Vector3>(prim + Offsets::Primitive::Size);
    if (!std::isfinite(size.x) || !std::isfinite(size.y) || !std::isfinite(size.z))
        return std::nullopt;
    return size;
}

bool has_valid_signature(std::uint64_t prim) {
    if (!prim) return false;
    const std::uint32_t raw = g_Memory.Read<std::uint32_t>(prim + Offsets::Primitive::Validate);
    constexpr std::uint32_t k = 0x6;
    return raw == k
        || (raw & 0xFFu) == k
        || ((raw >> 8) & 0xFFu) == k
        || ((raw >> 16) & 0xFFu) == k
        || ((raw >> 24) & 0xFFu) == k;
}

bool can_collide(std::uint64_t prim) {
    const std::uint8_t flags = g_Memory.Read<std::uint8_t>(prim + Offsets::Primitive::Flags);
    return (flags & static_cast<std::uint8_t>(Offsets::PrimitiveFlags::CanCollide)) != 0;
}

bool ray_intersects_obb(const Vector3& origin, const Vector3& dir,
                        const occluder_part& part, float max_distance, float* out_hit) {
    const Vector3 to_part = part.position - origin;
    const float sphere_radius = std::sqrt((std::max)(part.radius_sq, 0.0f));
    const float dist_sq = to_part.LengthSquared();
    const float combined = sphere_radius + max_distance;
    if (dist_sq > combined * combined)
        return false;

    const Vector3 local_origin = multiply_transpose(part.rotation, origin - part.position);
    const Vector3 local_dir = multiply_transpose(part.rotation, dir);
    const Vector3 half = part.half_size;

    float tmin = -(std::numeric_limits<float>::max)();
    float tmax = (std::numeric_limits<float>::max)();
    constexpr float eps = 1e-6f;

    for (int axis = 0; axis < 3; ++axis) {
        const float o = component(local_origin, axis);
        const float d = component(local_dir, axis);
        const float mn = -component(half, axis);
        const float mx = component(half, axis);

        if (std::fabs(d) < eps) {
            if (o < mn || o > mx)
                return false;
            continue;
        }

        float t1 = (mn - o) / d;
        float t2 = (mx - o) / d;
        if (t1 > t2) std::swap(t1, t2);
        tmin = (std::max)(tmin, t1);
        tmax = (std::min)(tmax, t2);
        if (tmin > tmax || tmax < 0.0f || tmin > max_distance)
            return false;
    }

    const float hit = (tmin >= 0.0f) ? tmin : tmax;
    if (hit < 0.0f || hit > max_distance || tmin > tmax)
        return false;
    if (out_hit) *out_hit = hit;
    return true;
}

int cell_coord(float value, float inv_cell) {
    if (!std::isfinite(value) || !std::isfinite(inv_cell) || std::fabs(inv_cell) < 1e-6f)
        return 0;
    float scaled = value * inv_cell;
    if (!std::isfinite(scaled))
        return scaled > 0.0f ? (INT_MAX / 4) : (INT_MIN / 4);
    scaled = std::clamp(scaled, -1'000'000.0f, 1'000'000.0f);
    return static_cast<int>(std::floor(scaled));
}

void insert_part_into_grid(occluder_cache& cache, std::uint32_t index, const occluder_part& part) {
    if (cache.cell_size <= 0.0f) return;
    const float inv = 1.0f / cache.cell_size;
    const float3x3& rot = part.rotation;
    const float hx = part.half_size.x, hy = part.half_size.y, hz = part.half_size.z;
    Vector3 extent(
        std::fabs(rot._11) * hx + std::fabs(rot._12) * hy + std::fabs(rot._13) * hz,
        std::fabs(rot._21) * hx + std::fabs(rot._22) * hy + std::fabs(rot._23) * hz,
        std::fabs(rot._31) * hx + std::fabs(rot._32) * hy + std::fabs(rot._33) * hz);
    extent.x += 2.0f; extent.y += 2.0f; extent.z += 2.0f;

    const Vector3 min = part.position - extent;
    const Vector3 max = part.position + extent;
    const int min_x = cell_coord(min.x, inv), min_y = cell_coord(min.y, inv), min_z = cell_coord(min.z, inv);
    const int max_x = cell_coord(max.x, inv), max_y = cell_coord(max.y, inv), max_z = cell_coord(max.z, inv);

    constexpr int k_max = 512;
    if ((max_x - min_x) > k_max || (max_y - min_y) > k_max || (max_z - min_z) > k_max)
        return;

    for (int x = min_x; x <= max_x; ++x)
        for (int y = min_y; y <= max_y; ++y)
            for (int z = min_z; z <= max_z; ++z)
                cache.grid[cell_key{ x, y, z }].push_back(index);
}

bool append_occluder(std::uint64_t primitive, occluder_cache& cache) {
    if (!primitive || !has_valid_signature(primitive) || !can_collide(primitive))
        return false;

    const auto size = read_size(primitive);
    const auto position = read_position(primitive);
    if (!size || !position) return false;

    constexpr float k_max_size = 500.0f;
    if (size->x <= 0.0f || size->y <= 0.0f || size->z <= 0.0f ||
        size->x > k_max_size || size->y > k_max_size || size->z > k_max_size)
        return false;

    occluder_part part{};
    part.primitive = primitive;
    part.position = *position;
    part.half_size = Vector3(size->x * 0.5f, size->y * 0.5f, size->z * 0.5f);
    part.rotation = read_rotation(primitive).value_or(identity_rotation());
    part.radius_sq = part.half_size.LengthSquared();
    cache.parts.push_back(part);
    insert_part_into_grid(cache, static_cast<std::uint32_t>(cache.parts.size() - 1), cache.parts.back());
    return true;
}

void step_builder(occluder_builder& builder, std::size_t step_count) {
    if (!builder.active || builder.complete || !builder.primitives_base)
        return;

    constexpr std::size_t k_null_run_limit = 16384;
    std::size_t processed = 0;
    while (processed < step_count && builder.cursor < builder.max_scan) {
        const std::uint64_t primitive = g_Memory.Read<std::uint64_t>(
            builder.primitives_base + builder.cursor * sizeof(std::uint64_t));
        ++builder.cursor;
        ++processed;

        if (!primitive) {
            ++builder.consecutive_null_slots;
            if (builder.found_non_null_slot && builder.consecutive_null_slots >= k_null_run_limit) {
                builder.complete = true;
                break;
            }
            continue;
        }

        builder.found_non_null_slot = true;
        builder.consecutive_null_slots = 0;

        if (builder.ignore_primitives.find(primitive) == builder.ignore_primitives.end())
            append_occluder(primitive, builder.building_cache);
    }

    if (builder.cursor >= builder.max_scan)
        builder.complete = true;

    if (builder.complete) {
        builder.active = false;
        builder.building_cache.complete = true;
        builder.building_cache.build_time = now_sec();
    }
}

std::atomic<std::shared_ptr<occluder_cache>>& cache_storage() {
    static std::atomic<std::shared_ptr<occluder_cache>> cached{ std::make_shared<occluder_cache>() };
    return cached;
}

occluder_builder& builder_storage() {
    static occluder_builder builder;
    return builder;
}

std::mutex& builder_mutex() {
    static std::mutex mu;
    return mu;
}

std::uint64_t part_primitive(const std::shared_ptr<Instance>& part) {
    if (!part || !g_Memory.IsValid(part->address))
        return 0;
    const std::uint64_t prim = g_Memory.Read<std::uint64_t>(
        part->address + Offsets::BasePart::Primitive);
    return g_Memory.IsValid(prim) ? prim : 0;
}

void collect_cache_primitives(const PlayerCache& cache, std::unordered_set<std::uint64_t>& out) {
    const std::shared_ptr<Instance>* parts[] = {
        &cache.head, &cache.humanoidRootPart, &cache.upperTorso, &cache.lowerTorso,
        &cache.leftUpperArm, &cache.leftLowerArm, &cache.leftHand,
        &cache.rightUpperArm, &cache.rightLowerArm, &cache.rightHand,
        &cache.leftUpperLeg, &cache.leftLowerLeg, &cache.leftFoot,
        &cache.rightUpperLeg, &cache.rightLowerLeg, &cache.rightFoot
    };
    for (const auto* p : parts) {
        if (const std::uint64_t prim = part_primitive(*p))
            out.insert(prim);
    }
}

void gather_player_primitives(std::unordered_set<std::uint64_t>& out) {
    out.clear();
    PlayerHandler::ForEachPlayer([&](const PlayerCache& cache) {
        collect_cache_primitives(cache, out);
    });
}

std::optional<std::uint64_t> primitives_root() {
    if (!Globals::Workspace || !g_Memory.IsValid(Globals::Workspace->address))
        return std::nullopt;

    const std::uint64_t world = g_Memory.Read<std::uint64_t>(
        Globals::Workspace->address + Offsets::Workspace::World);
    if (!g_Memory.IsValid(world))
        return std::nullopt;

    const std::uint64_t p2 = g_Memory.Read<std::uint64_t>(world + Offsets::World::Primitives);
    if (g_Memory.IsValid(p2))
        return p2;

    const std::uint64_t p1 = g_Memory.Read<std::uint64_t>(world + 0x240);
    if (g_Memory.IsValid(p1))
        return p1;

    return std::nullopt;
}

std::shared_ptr<occluder_cache> get_occluder_cache() {
    constexpr float k_cell_size = 32.0f;
    constexpr std::size_t k_max_scan = 524288;
    constexpr double refresh_interval = 4.0;
    constexpr double step_interval = 0.02;

    auto& cache_ref = cache_storage();
    auto cache_ptr = cache_ref.load(std::memory_order_acquire);
    const double now = now_sec();
    const bool empty = !cache_ptr || cache_ptr->parts.empty();
    const bool stale = cache_ptr && cache_ptr->complete && (now - cache_ptr->build_time) > refresh_interval;

    const auto root = primitives_root();
    const std::uint64_t base = root.value_or(0);
    auto& builder = builder_storage();

    {
        std::lock_guard<std::mutex> lock(builder_mutex());

        if (builder.active && builder.primitives_base != base)
            builder.reset();

        if ((empty || stale) && !builder.active && base) {
            std::unordered_set<std::uint64_t> ignore;
            gather_player_primitives(ignore);
            builder.start(base, std::move(ignore), k_cell_size, k_max_scan);
        }

        if (builder.active) {
            if (builder.last_step <= 0.0 || (now - builder.last_step) >= step_interval) {
                builder.last_step = now;
                step_builder(builder, 2048);
            }
            if (builder.complete) {
                auto new_cache = std::make_shared<occluder_cache>(std::move(builder.building_cache));
                cache_ref.store(std::move(new_cache), std::memory_order_release);
                builder.reset();
            }
        }
    }

    return cache_ref.load(std::memory_order_acquire);
}

bool line_of_sight_clear(const Vector3& from, const Vector3& to,
                         const occluder_cache& cache,
                         const std::unordered_set<std::uint64_t>& ignore) {
    if (!std::isfinite(from.x) || !std::isfinite(to.x))
        return true;

    Vector3 delta = to - from;
    float distance = delta.Length();
    if (!std::isfinite(distance) || distance <= 1e-5f)
        return true;
    delta /= distance;

    constexpr float k_hit_start = 0.15f;
    constexpr float k_hit_end = 0.55f;

    if (cache.parts.empty())
        return true;

    auto hit_blocks = [&](const occluder_part& part) -> bool {
        if (part.primitive && ignore.find(part.primitive) != ignore.end())
            return false;
        float hit = 0.0f;
        if (!ray_intersects_obb(from, delta, part, distance, &hit))
            return false;
        if (hit <= k_hit_start) return false;
        if ((distance - hit) <= k_hit_end) return false;
        return true;
    };

    if (cache.cell_size <= 0.0f || cache.grid.empty()) {
        for (const auto& part : cache.parts)
            if (hit_blocks(part)) return false;
        return true;
    }

    static std::atomic<std::uint64_t> query_counter{ 1 };
    const std::uint64_t query_id = query_counter.fetch_add(1, std::memory_order_relaxed) + 1;

    const float cell_size = cache.cell_size;
    const float inv_cell = 1.0f / cell_size;

    int cell_x = cell_coord(from.x, inv_cell);
    int cell_y = cell_coord(from.y, inv_cell);
    int cell_z = cell_coord(from.z, inv_cell);
    const int end_x = cell_coord(to.x, inv_cell);
    const int end_y = cell_coord(to.y, inv_cell);
    const int end_z = cell_coord(to.z, inv_cell);

    int step_x = 0, step_y = 0, step_z = 0;
    float t_max_x = INFINITY, t_max_y = INFINITY, t_max_z = INFINITY;
    float t_delta_x = INFINITY, t_delta_y = INFINITY, t_delta_z = INFINITY;

    auto setup_axis = [&](float origin, float dir, int cell, int& step, float& t_max, float& t_delta) {
        if (std::fabs(dir) < 1e-6f) {
            step = 0; t_max = INFINITY; t_delta = INFINITY;
            return;
        }
        if (dir > 0.0f) {
            step = 1;
            t_max = ((static_cast<float>(cell) + 1.0f) * cell_size - origin) / dir;
        } else {
            step = -1;
            t_max = (static_cast<float>(cell) * cell_size - origin) / dir;
        }
        t_delta = cell_size / std::fabs(dir);
    };

    setup_axis(from.x, delta.x, cell_x, step_x, t_max_x, t_delta_x);
    setup_axis(from.y, delta.y, cell_y, step_y, t_max_y, t_delta_y);
    setup_axis(from.z, delta.z, cell_z, step_z, t_max_z, t_delta_z);

    const int max_steps = 1 + std::abs(end_x - cell_x) + std::abs(end_y - cell_y) + std::abs(end_z - cell_z);
    float t = 0.0f;

    for (int step = 0; step <= max_steps; ++step) {
        auto it = cache.grid.find(cell_key{ cell_x, cell_y, cell_z });
        if (it != cache.grid.end()) {
            for (std::uint32_t index : it->second) {
                if (index >= cache.parts.size()) continue;
                auto& part = cache.parts[index];
                const std::uint64_t last = part.last_query_id.load(std::memory_order_relaxed);
                if (last == query_id) continue;
                part.last_query_id.store(query_id, std::memory_order_relaxed);
                if (hit_blocks(part))
                    return false;
            }
        }

        if (cell_x == end_x && cell_y == end_y && cell_z == end_z)
            break;

        if (t_max_x < t_max_y) {
            if (t_max_x < t_max_z) { cell_x += step_x; t = t_max_x; t_max_x += t_delta_x; }
            else { cell_z += step_z; t = t_max_z; t_max_z += t_delta_z; }
        } else {
            if (t_max_y < t_max_z) { cell_y += step_y; t = t_max_y; t_max_y += t_delta_y; }
            else { cell_z += step_z; t = t_max_z; t_max_z += t_delta_z; }
        }

        if (t > distance)
            break;
    }

    return true;
}

std::optional<Vector3> part_world_pos(const std::shared_ptr<Instance>& part) {
    if (!part || !g_Memory.IsValid(part->address))
        return std::nullopt;
    const Vector3 pos = BasePart(part->address).GetPosition();
    if (!std::isfinite(pos.x) || !std::isfinite(pos.y) || !std::isfinite(pos.z))
        return std::nullopt;
    return pos;
}

bool is_visible_impl(const PlayerCache& player, const Vector3& camera_pos,
                     const occluder_cache& occluders, float& out_coverage) {
    if (occluders.parts.empty()) {
        out_coverage = 1.0f;
        return true;
    }

    std::unordered_set<std::uint64_t> ignore;
    collect_cache_primitives(player, ignore);

    // Also ignore local character parts if resolvable
    if (Globals::Players && g_Memory.IsValid(Globals::Players->address)) {
        const std::uint64_t lp = g_Memory.Read<std::uint64_t>(
            Globals::Players->address + Offsets::Player::LocalPlayer);
        if (g_Memory.IsValid(lp)) {
            const std::uint64_t character = g_Memory.Read<std::uint64_t>(
                lp + Offsets::Player::ModelInstance);
            if (g_Memory.IsValid(character)) {
                for (const auto& child : Instance(character).GetChildren()) {
                    const auto cls = child.GetClassName();
                    if (cls == "Part" || cls == "MeshPart" || cls == "WedgePart" ||
                        cls == "CornerWedgePart" || cls == "UnionOperation" || cls == "TrussPart") {
                        const std::uint64_t prim = g_Memory.Read<std::uint64_t>(
                            child.address + Offsets::BasePart::Primitive);
                        if (g_Memory.IsValid(prim))
                            ignore.insert(prim);
                    }
                }
            }
        }
    }

    std::vector<Vector3> samples;
    samples.reserve(8);
    auto push = [&](const std::shared_ptr<Instance>& p) {
        if (auto pos = part_world_pos(p))
            samples.push_back(*pos);
    };

    push(player.head);
    push(player.humanoidRootPart);
    if (!player.isR6) {
        push(player.upperTorso);
        push(player.lowerTorso);
    }

    if (samples.empty()) {
        out_coverage = 1.0f;
        return true;
    }

    if (line_of_sight_clear(camera_pos, samples.front(), occluders, ignore)) {
        out_coverage = 1.0f;
        return true;
    }

    int clear = 0;
    const int total = static_cast<int>(samples.size());
    int required = (std::max)(1, static_cast<int>(std::ceil(total * 0.10f)));
    if (total <= 6) required = 1;
    required = std::clamp(required, 1, total);

    int tested = 0;
    for (const auto& sample : samples) {
        ++tested;
        if (line_of_sight_clear(camera_pos, sample, occluders, ignore)) {
            ++clear;
            if (clear >= required) {
                out_coverage = static_cast<float>(clear) / static_cast<float>(tested);
                return true;
            }
        }
        if (clear + (total - tested) < required)
            break;
    }

    out_coverage = static_cast<float>(clear) / static_cast<float>((std::max)(tested, 1));
    return clear >= required;
}

} // namespace

bool IsEnabled() {
    return g_Settings.misc.raycast_engine;
}

void Reset() {
    cache_storage().store(std::make_shared<occluder_cache>(), std::memory_order_release);
    std::lock_guard<std::mutex> lock(builder_mutex());
    builder_storage().reset();
}

void Tick() {
    if (!IsEnabled())
        return;
    (void)get_occluder_cache();
}

Result IsPlayerVisible(const PlayerCache& player, const Vector3& camera_pos) {
    if (!IsEnabled())
        return Result{};

    if (!std::isfinite(camera_pos.x) || !std::isfinite(camera_pos.y) || !std::isfinite(camera_pos.z))
        return Result{};

    struct smoothed_state {
        float smoothed = 1.0f;
        bool visible = true;
        double last_time = 0.0;
        double last_query_time = 0.0;
        int visible_confirmation = 0;
        int occluded_confirmation = 0;
        Result last_result{};
    };
    thread_local std::unordered_map<std::uint64_t, smoothed_state> smooth_map;

    smoothed_state& state = smooth_map[player.address];
    const double now = now_sec();
    constexpr double k_query_interval = 0.015;
    if (state.last_query_time != 0.0 && (now - state.last_query_time) < k_query_interval)
        return state.last_result;

    const auto occluders = get_occluder_cache();
    if (!occluders)
        return Result{};

    float coverage = 1.0f;
    const bool visible_raw = is_visible_impl(player, camera_pos, *occluders, coverage);
    const float alpha = (state.last_time == 0.0) ? 1.0f : (visible_raw ? 0.4f : 0.28f);
    state.smoothed = state.smoothed * (1.0f - alpha) + coverage * alpha;

    if (visible_raw) {
        state.visible_confirmation = (std::min)(state.visible_confirmation + 1, 16);
        state.occluded_confirmation = 0;
        state.smoothed = (std::max)(state.smoothed, coverage);
    } else {
        state.occluded_confirmation = (std::min)(state.occluded_confirmation + 1, 16);
        state.visible_confirmation = 0;
    }

    constexpr float on_threshold = 0.48f;
    constexpr float off_threshold = 0.22f;
    if (state.visible) {
        if (!visible_raw && state.smoothed <= off_threshold && state.occluded_confirmation >= 4)
            state.visible = false;
    } else {
        if ((state.smoothed >= on_threshold && state.visible_confirmation >= 2) ||
            state.visible_confirmation >= 3)
            state.visible = true;
    }

    if (state.last_time == 0.0) {
        state.visible = visible_raw;
        state.smoothed = coverage;
        state.visible_confirmation = visible_raw ? 1 : 0;
        state.occluded_confirmation = visible_raw ? 0 : 1;
    }

    state.last_time = now;
    state.last_query_time = now;
    state.last_result = Result{ state.visible, state.smoothed };
    return state.last_result;
}

} // namespace Cheat::Features::RaycastEngine
