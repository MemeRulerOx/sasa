#include "Config.h"
#include "../../Settings.h"

#include <Windows.h>
#include <algorithm>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <unordered_map>

namespace Cheat {
namespace Config {
namespace {

std::string SanitizeName(std::string name)
{
    for (char& c : name) {
        const bool ok =
            (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '_' || c == '-' || c == ' ';
        if (!ok) c = '_';
    }
    while (!name.empty() && (name.front() == ' ' || name.front() == '.'))
        name.erase(name.begin());
    while (!name.empty() && (name.back() == ' ' || name.back() == '.'))
        name.pop_back();
    if (name.empty())
        name = "config";
    if (name.size() > 48)
        name.resize(48);
    return name;
}

std::string PathFor(const std::string& name)
{
    return Directory() + "\\" + SanitizeName(name) + ".cfg";
}

void EnsureDir(const std::string& dir)
{
    CreateDirectoryA(dir.c_str(), nullptr);
}

using KV = std::unordered_map<std::string, std::string>;

void PutBool(std::ostringstream& out, const char* key, bool v)
{
    out << key << '=' << (v ? 1 : 0) << '\n';
}
void PutInt(std::ostringstream& out, const char* key, int v)
{
    out << key << '=' << v << '\n';
}
void PutFloat(std::ostringstream& out, const char* key, float v)
{
    char buf[64];
    std::snprintf(buf, sizeof(buf), "%.6g", v);
    out << key << '=' << buf << '\n';
}
void PutF4(std::ostringstream& out, const char* key, const float c[4])
{
    char buf[128];
    std::snprintf(buf, sizeof(buf), "%.6g,%.6g,%.6g,%.6g", c[0], c[1], c[2], c[3]);
    out << key << '=' << buf << '\n';
}
void PutF2(std::ostringstream& out, const char* key, const float c[2])
{
    char buf[64];
    std::snprintf(buf, sizeof(buf), "%.6g,%.6g", c[0], c[1]);
    out << key << '=' << buf << '\n';
}

bool GetBool(const KV& kv, const char* key, bool& out)
{
    auto it = kv.find(key);
    if (it == kv.end()) return false;
    out = (it->second != "0" && it->second != "false");
    return true;
}
bool GetInt(const KV& kv, const char* key, int& out)
{
    auto it = kv.find(key);
    if (it == kv.end()) return false;
    out = std::atoi(it->second.c_str());
    return true;
}
bool GetFloat(const KV& kv, const char* key, float& out)
{
    auto it = kv.find(key);
    if (it == kv.end()) return false;
    out = static_cast<float>(std::atof(it->second.c_str()));
    return true;
}
bool GetF4(const KV& kv, const char* key, float out[4])
{
    auto it = kv.find(key);
    if (it == kv.end()) return false;
    float a = out[0], b = out[1], c = out[2], d = out[3];
    if (sscanf_s(it->second.c_str(), "%f,%f,%f,%f", &a, &b, &c, &d) == 4) {
        out[0] = a; out[1] = b; out[2] = c; out[3] = d;
        return true;
    }
    return false;
}
bool GetF2(const KV& kv, const char* key, float out[2])
{
    auto it = kv.find(key);
    if (it == kv.end()) return false;
    float a = out[0], b = out[1];
    if (sscanf_s(it->second.c_str(), "%f,%f", &a, &b) == 2) {
        out[0] = a; out[1] = b;
        return true;
    }
    return false;
}

void WriteAimCfg(std::ostringstream& out, const char* prefix, const Settings::AimbotConfig& c)
{
    auto k = [&](const char* name) {
        static char buf[128];
        std::snprintf(buf, sizeof(buf), "%s.%s", prefix, name);
        return buf;
    };
    PutBool(out, k("fov_enabled"), c.fov_enabled);
    PutFloat(out, k("fov_size"), c.fov_size);
    PutInt(out, k("fov_position"), c.fov_position);
    PutInt(out, k("fov_style"), c.fov_style);
    PutBool(out, k("fov_outline"), c.fov_outline);
    PutBool(out, k("distance_check"), c.distance_check);
    PutFloat(out, k("max_distance"), c.max_distance);
    PutBool(out, k("visible_only"), c.visible_only);
    PutBool(out, k("dead_check"), c.dead_check);
    PutInt(out, k("part_select"), c.part_select);
    PutFloat(out, k("switch_time"), c.switch_time);
    PutBool(out, k("hitchance_enabled"), c.hitchance_enabled);
    PutFloat(out, k("hitchance"), c.hitchance);
    PutFloat(out, k("smooth_x"), c.smooth_x);
    PutFloat(out, k("smooth_y"), c.smooth_y);
    PutBool(out, k("humanize"), c.humanize);
    PutFloat(out, k("reaction_ms"), c.reaction_ms);
    PutBool(out, k("sticky"), c.sticky);
    PutFloat(out, k("sticky_fov_scale"), c.sticky_fov_scale);
    PutBool(out, k("prediction"), c.prediction);
    PutFloat(out, k("bullet_speed"), c.bullet_speed);
    PutF4(out, k("fov_color"), c.fov_color);
    PutF4(out, k("fov_outline_color"), c.fov_outline_color);
    PutBool(out, k("tracer"), c.tracer);
    PutF4(out, k("tracer_color"), c.tracer_color);
    for (int i = 0; i < Settings::AIM_PART_COUNT; ++i) {
        char key[64];
        std::snprintf(key, sizeof(key), "%s.part_tier_%d", prefix, i);
        PutInt(out, key, c.part_tier[i]);
    }
}

void ReadAimCfg(const KV& kv, const char* prefix, Settings::AimbotConfig& c)
{
    auto k = [&](const char* name) {
        static char buf[128];
        std::snprintf(buf, sizeof(buf), "%s.%s", prefix, name);
        return buf;
    };
    GetBool(kv, k("fov_enabled"), c.fov_enabled);
    GetFloat(kv, k("fov_size"), c.fov_size);
    GetInt(kv, k("fov_position"), c.fov_position);
    GetInt(kv, k("fov_style"), c.fov_style);
    GetBool(kv, k("fov_outline"), c.fov_outline);
    GetBool(kv, k("distance_check"), c.distance_check);
    GetFloat(kv, k("max_distance"), c.max_distance);
    GetBool(kv, k("visible_only"), c.visible_only);
    GetBool(kv, k("dead_check"), c.dead_check);
    GetInt(kv, k("part_select"), c.part_select);
    GetFloat(kv, k("switch_time"), c.switch_time);
    GetBool(kv, k("hitchance_enabled"), c.hitchance_enabled);
    GetFloat(kv, k("hitchance"), c.hitchance);
    GetFloat(kv, k("smooth_x"), c.smooth_x);
    GetFloat(kv, k("smooth_y"), c.smooth_y);
    GetBool(kv, k("humanize"), c.humanize);
    GetFloat(kv, k("reaction_ms"), c.reaction_ms);
    GetBool(kv, k("sticky"), c.sticky);
    GetFloat(kv, k("sticky_fov_scale"), c.sticky_fov_scale);
    GetBool(kv, k("prediction"), c.prediction);
    GetFloat(kv, k("bullet_speed"), c.bullet_speed);
    GetF4(kv, k("fov_color"), c.fov_color);
    GetF4(kv, k("fov_outline_color"), c.fov_outline_color);
    GetBool(kv, k("tracer"), c.tracer);
    GetF4(kv, k("tracer_color"), c.tracer_color);
    for (int i = 0; i < Settings::AIM_PART_COUNT; ++i) {
        char key[64];
        std::snprintf(key, sizeof(key), "%s.part_tier_%d", prefix, i);
        GetInt(kv, key, c.part_tier[i]);
    }
    c.SyncPartsFromTiers();
}

} // namespace

std::string Directory()
{
    char module[MAX_PATH]{};
    GetModuleFileNameA(nullptr, module, MAX_PATH);
    std::string path(module);
    const auto slash = path.find_last_of("\\/");
    if (slash != std::string::npos)
        path.resize(slash);
    path += "\\configs";
    return path;
}

std::vector<std::string> List()
{
    std::vector<std::string> out;
    const std::string dir = Directory();
    EnsureDir(dir);

    WIN32_FIND_DATAA fd{};
    const std::string pattern = dir + "\\*.cfg";
    HANDLE h = FindFirstFileA(pattern.c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE)
        return out;

    do {
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
            continue;
        std::string name = fd.cFileName;
        if (name.size() > 4 && name.substr(name.size() - 4) == ".cfg")
            name.resize(name.size() - 4);
        out.push_back(name);
    } while (FindNextFileA(h, &fd));
    FindClose(h);

    std::sort(out.begin(), out.end());
    return out;
}

bool Save(const std::string& name)
{
    const std::string dir = Directory();
    EnsureDir(dir);
    const std::string path = PathFor(name);

    std::ostringstream out;
    out << "# SASA config\n";
    auto& s = g_Settings;

    PutBool(out, "esp.enabled", s.esp.enabled);
    PutBool(out, "esp.draw_local", s.esp.draw_local);
    PutBool(out, "esp.box", s.esp.box);
    PutBool(out, "esp.name", s.esp.name);
    PutBool(out, "esp.skeleton", s.esp.skeleton);
    PutBool(out, "esp.chams", s.esp.chams);
    PutInt(out, "esp.chams_mode", s.esp.chams_mode);
    PutInt(out, "esp.chams_shader", s.esp.chams_shader);
    PutBool(out, "esp.healthbar", s.esp.healthbar);
    PutBool(out, "esp.health_text", s.esp.health_text);
    PutBool(out, "esp.distance", s.esp.distance);
    PutBool(out, "esp.tool", s.esp.tool);
    PutBool(out, "esp.flags", s.esp.flags);
    PutBool(out, "esp.tracer", s.esp.tracer);
    PutInt(out, "esp.tracer_origin", s.esp.tracer_origin);
    PutBool(out, "esp.offscreen_arrows", s.esp.offscreen_arrows);
    PutFloat(out, "esp.arrow_size", s.esp.arrow_size);
    PutFloat(out, "esp.arrow_radius", s.esp.arrow_radius);
    for (int i = 0; i < Settings::ARROW_INFO_COUNT; ++i) {
        char key[48];
        std::snprintf(key, sizeof(key), "esp.arrow_info_%d", i);
        PutBool(out, key, s.esp.arrow_info[i]);
    }
    PutInt(out, "esp.font", s.esp.font);
    PutFloat(out, "esp.font_size", s.esp.font_size);
    PutInt(out, "esp.box_mode", s.esp.box_mode);
    PutInt(out, "esp.name_mode", s.esp.name_mode);
    PutInt(out, "esp.distance_unit", s.esp.distance_unit);
    PutBool(out, "esp.distance_check", s.esp.distance_check);
    PutFloat(out, "esp.max_distance", s.esp.max_distance);
    PutBool(out, "esp.dead_check", s.esp.dead_check);
    PutBool(out, "esp.body_corpse", s.esp.body_corpse);
    PutF4(out, "esp.corpse_color", s.esp.corpse_color);
    PutInt(out, "esp.name_side", s.esp.name_side);
    PutFloat(out, "esp.name_off", s.esp.name_off);
    PutInt(out, "esp.distance_side", s.esp.distance_side);
    PutFloat(out, "esp.distance_off", s.esp.distance_off);
    PutInt(out, "esp.tool_side", s.esp.tool_side);
    PutFloat(out, "esp.tool_off", s.esp.tool_off);
    PutInt(out, "esp.flags_side", s.esp.flags_side);
    PutFloat(out, "esp.flags_off", s.esp.flags_off);
    PutInt(out, "esp.health_text_side", s.esp.health_text_side);
    PutFloat(out, "esp.health_text_off", s.esp.health_text_off);
    PutInt(out, "esp.healthbar_side", s.esp.healthbar_side);
    PutF4(out, "esp.box_color", s.esp.box_color);
    PutF4(out, "esp.name_color", s.esp.name_color);
    PutF4(out, "esp.skeleton_color", s.esp.skeleton_color);
    PutF4(out, "esp.chams_outline_color", s.esp.chams_outline_color);
    PutF4(out, "esp.chams_fill_color", s.esp.chams_fill_color);
    PutF4(out, "esp.distance_color", s.esp.distance_color);
    PutF4(out, "esp.tool_color", s.esp.tool_color);
    PutF4(out, "esp.tracer_color", s.esp.tracer_color);
    PutF4(out, "esp.arrow_color", s.esp.arrow_color);

    PutInt(out, "aim.bind", s.aim.bind);
    PutInt(out, "aim.bind_mode", s.aim.bind_mode);
    PutInt(out, "aim.type", s.aim.type);
    PutInt(out, "aim.silent_method", s.aim.silent_method);
    PutBool(out, "aim.force_magic_bullet", s.aim.force_magic_bullet);
    PutInt(out, "aim.force_magic_key", s.aim.force_magic_key);
    PutInt(out, "aim.force_magic_mode", s.aim.force_magic_mode);
    WriteAimCfg(out, "aim.mouse", s.aim.mouse);
    WriteAimCfg(out, "aim.camera", s.aim.camera);
    WriteAimCfg(out, "aim.silent", s.aim.silent);

    PutBool(out, "world.no_shadow", s.world.no_shadow);
    PutFloat(out, "world.brightness", s.world.brightness);
    PutBool(out, "world.fog", s.world.fog);
    PutFloat(out, "world.fog_start", s.world.fog_start);
    PutFloat(out, "world.fog_end", s.world.fog_end);
    PutF4(out, "world.fog_color", s.world.fog_color);

    PutBool(out, "crosshair.enabled", s.crosshair.enabled);
    PutFloat(out, "crosshair.length", s.crosshair.length);
    PutFloat(out, "crosshair.gap", s.crosshair.gap);
    PutFloat(out, "crosshair.thickness", s.crosshair.thickness);
    PutBool(out, "crosshair.spin", s.crosshair.spin);
    PutFloat(out, "crosshair.spin_speed", s.crosshair.spin_speed);
    PutBool(out, "crosshair.outline", s.crosshair.outline);
    PutBool(out, "crosshair.dot", s.crosshair.dot);
    PutFloat(out, "crosshair.dot_size", s.crosshair.dot_size);
    PutF4(out, "crosshair.color", s.crosshair.color);
    PutF4(out, "crosshair.outline_color", s.crosshair.outline_color);

    PutBool(out, "misc.fps_unlock", s.misc.fps_unlock);
    PutInt(out, "misc.fps_cap", s.misc.fps_cap);
    PutBool(out, "misc.fov", s.misc.fov);
    PutFloat(out, "misc.fov_value", s.misc.fov_value);
    PutBool(out, "misc.walkspeed", s.misc.walkspeed);
    PutInt(out, "misc.walkspeed_mode", s.misc.walkspeed_mode);
    PutFloat(out, "misc.walkspeed_value", s.misc.walkspeed_value);
    PutBool(out, "misc.jump", s.misc.jump);
    PutFloat(out, "misc.jump_power", s.misc.jump_power);
    PutBool(out, "misc.fly", s.misc.fly);
    PutFloat(out, "misc.fly_speed", s.misc.fly_speed);
    PutInt(out, "misc.fly_key", s.misc.fly_key);
    PutBool(out, "misc.noclip", s.misc.noclip);
    PutBool(out, "misc.inf_jump", s.misc.inf_jump);
    PutBool(out, "misc.teamcheck", s.misc.teamcheck);
    PutBool(out, "misc.raycast_engine", s.misc.raycast_engine);
    PutBool(out, "misc.explorer", s.misc.explorer);

    PutInt(out, "gui.theme", s.gui.theme);
    PutInt(out, "gui.font", s.gui.font);
    PutF4(out, "gui.accent", s.gui.accent);
    PutF4(out, "gui.text_active", s.gui.text_active);
    PutF4(out, "gui.text_inactive", s.gui.text_inactive);
    PutF4(out, "gui.outer_border", s.gui.outer_border);
    PutF4(out, "gui.inner_border", s.gui.inner_border);
    PutF4(out, "gui.panel_fill", s.gui.panel_fill);
    PutF4(out, "gui.content_outer", s.gui.content_outer);
    PutF4(out, "gui.content_inner", s.gui.content_inner);
    PutF4(out, "gui.content_fill", s.gui.content_fill);
    PutF4(out, "gui.child_fill", s.gui.child_fill);

    PutBool(out, "killfx.enabled", s.killfx.enabled);
    PutInt(out, "killfx.effect", s.killfx.effect);
    PutBool(out, "hitmarker.enabled", s.hitmarker.enabled);
    PutFloat(out, "hitmarker.size", s.hitmarker.size);
    PutFloat(out, "hitmarker.duration", s.hitmarker.duration);
    PutBool(out, "hitsound.enabled", s.hitsound.enabled);
    PutInt(out, "hitsound.index", s.hitsound.index);
    PutFloat(out, "hitsound.volume", s.hitsound.volume);
    PutBool(out, "hitdata.enabled", s.hitdata.enabled);

    std::ofstream file(path, std::ios::trunc);
    if (!file) return false;
    file << out.str();
    return static_cast<bool>(file);
}

bool Load(const std::string& name)
{
    const std::string path = PathFor(name);
    std::ifstream file(path);
    if (!file) return false;

    KV kv;
    std::string line;
    while (std::getline(file, line)) {
        if (line.empty() || line[0] == '#' || line[0] == ';')
            continue;
        const auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        kv[line.substr(0, eq)] = line.substr(eq + 1);
    }

    auto& s = g_Settings;
    GetBool(kv, "esp.enabled", s.esp.enabled);
    GetBool(kv, "esp.draw_local", s.esp.draw_local);
    GetBool(kv, "esp.box", s.esp.box);
    GetBool(kv, "esp.name", s.esp.name);
    GetBool(kv, "esp.skeleton", s.esp.skeleton);
    GetBool(kv, "esp.chams", s.esp.chams);
    GetInt(kv, "esp.chams_mode", s.esp.chams_mode);
    GetInt(kv, "esp.chams_shader", s.esp.chams_shader);
    GetBool(kv, "esp.healthbar", s.esp.healthbar);
    GetBool(kv, "esp.health_text", s.esp.health_text);
    GetBool(kv, "esp.distance", s.esp.distance);
    GetBool(kv, "esp.tool", s.esp.tool);
    GetBool(kv, "esp.flags", s.esp.flags);
    GetBool(kv, "esp.tracer", s.esp.tracer);
    GetInt(kv, "esp.tracer_origin", s.esp.tracer_origin);
    GetBool(kv, "esp.offscreen_arrows", s.esp.offscreen_arrows);
    GetFloat(kv, "esp.arrow_size", s.esp.arrow_size);
    GetFloat(kv, "esp.arrow_radius", s.esp.arrow_radius);
    for (int i = 0; i < Settings::ARROW_INFO_COUNT; ++i) {
        char key[48];
        std::snprintf(key, sizeof(key), "esp.arrow_info_%d", i);
        GetBool(kv, key, s.esp.arrow_info[i]);
    }
    GetInt(kv, "esp.font", s.esp.font);
    GetFloat(kv, "esp.font_size", s.esp.font_size);
    GetInt(kv, "esp.box_mode", s.esp.box_mode);
    GetInt(kv, "esp.name_mode", s.esp.name_mode);
    GetInt(kv, "esp.distance_unit", s.esp.distance_unit);
    GetBool(kv, "esp.distance_check", s.esp.distance_check);
    GetFloat(kv, "esp.max_distance", s.esp.max_distance);
    GetBool(kv, "esp.dead_check", s.esp.dead_check);
    GetBool(kv, "esp.body_corpse", s.esp.body_corpse);
    GetF4(kv, "esp.corpse_color", s.esp.corpse_color);
    GetInt(kv, "esp.name_side", s.esp.name_side);
    GetFloat(kv, "esp.name_off", s.esp.name_off);
    GetInt(kv, "esp.distance_side", s.esp.distance_side);
    GetFloat(kv, "esp.distance_off", s.esp.distance_off);
    GetInt(kv, "esp.tool_side", s.esp.tool_side);
    GetFloat(kv, "esp.tool_off", s.esp.tool_off);
    GetInt(kv, "esp.flags_side", s.esp.flags_side);
    GetFloat(kv, "esp.flags_off", s.esp.flags_off);
    GetInt(kv, "esp.health_text_side", s.esp.health_text_side);
    GetFloat(kv, "esp.health_text_off", s.esp.health_text_off);
    GetInt(kv, "esp.healthbar_side", s.esp.healthbar_side);
    GetF4(kv, "esp.box_color", s.esp.box_color);
    GetF4(kv, "esp.name_color", s.esp.name_color);
    GetF4(kv, "esp.skeleton_color", s.esp.skeleton_color);
    GetF4(kv, "esp.chams_outline_color", s.esp.chams_outline_color);
    GetF4(kv, "esp.chams_fill_color", s.esp.chams_fill_color);
    GetF4(kv, "esp.distance_color", s.esp.distance_color);
    GetF4(kv, "esp.tool_color", s.esp.tool_color);
    GetF4(kv, "esp.tracer_color", s.esp.tracer_color);
    GetF4(kv, "esp.arrow_color", s.esp.arrow_color);

    GetInt(kv, "aim.bind", s.aim.bind);
    GetInt(kv, "aim.bind_mode", s.aim.bind_mode);
    GetInt(kv, "aim.type", s.aim.type);
    GetInt(kv, "aim.silent_method", s.aim.silent_method);
    GetBool(kv, "aim.force_magic_bullet", s.aim.force_magic_bullet);
    GetInt(kv, "aim.force_magic_key", s.aim.force_magic_key);
    GetInt(kv, "aim.force_magic_mode", s.aim.force_magic_mode);
    ReadAimCfg(kv, "aim.mouse", s.aim.mouse);
    ReadAimCfg(kv, "aim.camera", s.aim.camera);
    ReadAimCfg(kv, "aim.silent", s.aim.silent);

    GetBool(kv, "world.no_shadow", s.world.no_shadow);
    GetFloat(kv, "world.brightness", s.world.brightness);
    GetBool(kv, "world.fog", s.world.fog);
    GetFloat(kv, "world.fog_start", s.world.fog_start);
    GetFloat(kv, "world.fog_end", s.world.fog_end);
    GetF4(kv, "world.fog_color", s.world.fog_color);

    GetBool(kv, "crosshair.enabled", s.crosshair.enabled);
    GetFloat(kv, "crosshair.length", s.crosshair.length);
    GetFloat(kv, "crosshair.gap", s.crosshair.gap);
    GetFloat(kv, "crosshair.thickness", s.crosshair.thickness);
    GetBool(kv, "crosshair.spin", s.crosshair.spin);
    GetFloat(kv, "crosshair.spin_speed", s.crosshair.spin_speed);
    GetBool(kv, "crosshair.outline", s.crosshair.outline);
    GetBool(kv, "crosshair.dot", s.crosshair.dot);
    GetFloat(kv, "crosshair.dot_size", s.crosshair.dot_size);
    GetF4(kv, "crosshair.color", s.crosshair.color);
    GetF4(kv, "crosshair.outline_color", s.crosshair.outline_color);

    GetBool(kv, "misc.fps_unlock", s.misc.fps_unlock);
    GetInt(kv, "misc.fps_cap", s.misc.fps_cap);
    GetBool(kv, "misc.fov", s.misc.fov);
    GetFloat(kv, "misc.fov_value", s.misc.fov_value);
    GetBool(kv, "misc.walkspeed", s.misc.walkspeed);
    GetInt(kv, "misc.walkspeed_mode", s.misc.walkspeed_mode);
    GetFloat(kv, "misc.walkspeed_value", s.misc.walkspeed_value);
    GetBool(kv, "misc.jump", s.misc.jump);
    GetFloat(kv, "misc.jump_power", s.misc.jump_power);
    GetBool(kv, "misc.fly", s.misc.fly);
    GetFloat(kv, "misc.fly_speed", s.misc.fly_speed);
    GetInt(kv, "misc.fly_key", s.misc.fly_key);
    GetBool(kv, "misc.noclip", s.misc.noclip);
    GetBool(kv, "misc.inf_jump", s.misc.inf_jump);
    GetBool(kv, "misc.teamcheck", s.misc.teamcheck);
    GetBool(kv, "misc.raycast_engine", s.misc.raycast_engine);
    GetBool(kv, "misc.explorer", s.misc.explorer);

    GetInt(kv, "gui.theme", s.gui.theme);
    GetInt(kv, "gui.font", s.gui.font);
    GetF4(kv, "gui.accent", s.gui.accent);
    GetF4(kv, "gui.text_active", s.gui.text_active);
    GetF4(kv, "gui.text_inactive", s.gui.text_inactive);
    GetF4(kv, "gui.outer_border", s.gui.outer_border);
    GetF4(kv, "gui.inner_border", s.gui.inner_border);
    GetF4(kv, "gui.panel_fill", s.gui.panel_fill);
    GetF4(kv, "gui.content_outer", s.gui.content_outer);
    GetF4(kv, "gui.content_inner", s.gui.content_inner);
    GetF4(kv, "gui.content_fill", s.gui.content_fill);
    GetF4(kv, "gui.child_fill", s.gui.child_fill);

    GetBool(kv, "killfx.enabled", s.killfx.enabled);
    GetInt(kv, "killfx.effect", s.killfx.effect);
    GetBool(kv, "hitmarker.enabled", s.hitmarker.enabled);
    GetFloat(kv, "hitmarker.size", s.hitmarker.size);
    GetFloat(kv, "hitmarker.duration", s.hitmarker.duration);
    GetBool(kv, "hitsound.enabled", s.hitsound.enabled);
    GetInt(kv, "hitsound.index", s.hitsound.index);
    GetFloat(kv, "hitsound.volume", s.hitsound.volume);
    GetBool(kv, "hitdata.enabled", s.hitdata.enabled);

    return true;
}

bool Remove(const std::string& name)
{
    return DeleteFileA(PathFor(name).c_str()) != 0;
}

} // namespace Config
} // namespace Cheat
