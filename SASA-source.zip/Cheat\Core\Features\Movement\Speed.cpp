#include "Speed.h"

#include "../../Globals/Globals.h"
#include "../../Memory/Memory.h"
#include "../../Roblox/Engine/Offsets/Offsets.h"
#include "../../Roblox/Engine/Classes/Classes.h"
#include "../../../Renderer/Renderer.h"
#include "../../../Settings.h"

#include <Windows.h>
#include <atomic>
#include <chrono>
#include <cmath>
#include <thread>
#include <algorithm>
#include <optional>

#undef GetClassName

namespace {

std::atomic<bool> g_run{ false };
std::thread       g_thread;

constexpr auto k_idle_sleep = std::chrono::milliseconds(8);
constexpr auto k_walkspeed_sleep = std::chrono::milliseconds(5);
constexpr float k_walkspeed_controller_speed = 0.1f;
constexpr float k_default_walkspeed = 16.0f;
constexpr int k_walkspeed_position_repetitions = 16;

enum class walkspeed_mode_t
{
    position = 0,
    humanoid
};

bool chat_is_focused()
{
    if (!Cheat::Globals::InstanceDataModel.address)
        return false;

    static std::uint64_t s_bar = 0;
    static std::uint64_t s_dm = 0;

    if (s_dm != Cheat::Globals::InstanceDataModel.address || !g_Memory.IsValid(s_bar)) {
        s_dm = Cheat::Globals::InstanceDataModel.address;
        s_bar = 0;
        for (const auto& child : Cheat::Globals::InstanceDataModel.GetChildren()) {
            if (child.GetName() != "TextChatService" && child.GetClassName() != "TextChatService")
                continue;
            for (const auto& cfg : child.GetChildren()) {
                if (cfg.GetName() == "ChatInputBarConfiguration") {
                    s_bar = cfg.address;
                    break;
                }
            }
            break;
        }
    }

    if (!g_Memory.IsValid(s_bar))
        return false;

    const std::uint32_t flags = g_Memory.Read<std::uint32_t>(s_bar + Offsets::Chat::IsFocused);
    return (flags & 0x10000u) != 0;
}

bool roblox_has_focus()
{
    const HWND window = Cheat::Renderer::GetGameHwnd();
    return window && IsWindow(window) && GetForegroundWindow() == window;
}

bool KeyActive(int key, int mode, bool& toggled, bool& was_pressed)
{
    if (key == 0)
        return true;

    const bool pressed = (GetAsyncKeyState(key) & 0x8000) != 0;
    if (mode == 1) {
        if (pressed && !was_pressed)
            toggled = !toggled;
        was_pressed = pressed;
        return toggled;
    }

    was_pressed = pressed;
    return pressed;
}

std::uint64_t LocalCharacter()
{
    if (!Cheat::Globals::Players || !g_Memory.IsValid(Cheat::Globals::Players->address))
        return 0;
    const std::uint64_t local = g_Memory.Read<std::uint64_t>(
        Cheat::Globals::Players->address + Offsets::Player::LocalPlayer);
    if (!g_Memory.IsValid(local))
        return 0;
    const std::uint64_t character = g_Memory.Read<std::uint64_t>(
        local + Offsets::Player::ModelInstance);
    return g_Memory.IsValid(character) ? character : 0;
}

bool ResolveLocal(std::uint64_t& out_hrp, std::uint64_t& out_prim, std::uint64_t& out_humanoid)
{
    out_hrp = 0;
    out_prim = 0;
    out_humanoid = 0;

    const std::uint64_t character = LocalCharacter();
    if (!character)
        return false;

    for (const auto& child : Cheat::Instance(character).GetChildren()) {
        if (!out_humanoid && child.GetClassName() == "Humanoid")
            out_humanoid = child.address;
        if (!out_hrp && child.GetName() == "HumanoidRootPart") {
            out_hrp = child.address;
            out_prim = g_Memory.Read<std::uint64_t>(out_hrp + Offsets::BasePart::Primitive);
        }
    }

    return g_Memory.IsValid(out_hrp) && g_Memory.IsValid(out_prim) && g_Memory.IsValid(out_humanoid);
}

std::optional<float> get_humanoid_walkspeed(std::uint64_t humanoid)
{
    if (!g_Memory.IsValid(humanoid))
        return std::nullopt;
    const float value = g_Memory.Read<float>(humanoid + Offsets::Humanoid::Walkspeed);
    if (!std::isfinite(value))
        return std::nullopt;
    return value;
}

bool set_humanoid_walkspeed(std::uint64_t humanoid, float speed)
{
    if (!g_Memory.IsValid(humanoid) || !std::isfinite(speed))
        return false;

    bool success = true;
    g_Memory.Write<float>(humanoid + Offsets::Humanoid::Walkspeed, speed);
    g_Memory.Write<float>(humanoid + Offsets::Humanoid::WalkspeedCheck, speed);
    return success;
}

bool get_humanoid_move_velocity(std::uint64_t humanoid, float speed, Vector3& out_velocity)
{
    out_velocity = {};
    if (!g_Memory.IsValid(humanoid) || speed <= 0.0f)
        return false;

    const Vector3 move_direction = Cheat::Humanoid(humanoid).GetMoveDirection();
    Vector3 direction(move_direction.x, 0.0f, move_direction.z);
    const float len_sq = direction.LengthSquared();
    if (!std::isfinite(len_sq) || len_sq < 1e-4f)
        return false;

    const float len = std::sqrt(len_sq);
    if (!std::isfinite(len) || len < 1e-4f)
        return false;

    if (len > 1.0f)
        direction /= len;

    out_velocity = direction * speed;
    return true;
}

bool write_horizontal_position_components(std::uint64_t address, float x, float z)
{
    if (!address)
        return false;
    g_Memory.Write<float>(address, x);
    g_Memory.Write<float>(address + sizeof(float) * 2, z);
    return true;
}

bool set_horizontal_position(std::uint64_t primitive, float x, float z)
{
    if (!primitive)
        return false;

    bool success = false;
    success |= write_horizontal_position_components(
        primitive + Offsets::Primitive::Position, x, z);

    const auto is_valid_ptr = [](std::uint64_t ptr) -> bool {
        constexpr std::uint64_t k_min = 0x10000;
        constexpr std::uint64_t k_max = 0x00007FFFFFFFFFFF;
        return ptr >= k_min && ptr <= k_max;
    };

    const std::uint64_t props_ptr = g_Memory.Read<std::uint64_t>(
        primitive + Offsets::Primitive::Properties);
    if (is_valid_ptr(props_ptr)) {
        success |= write_horizontal_position_components(
            props_ptr + Offsets::Primitive::PropertyPosition, x, z);
    } else {
        success |= write_horizontal_position_components(
            primitive + Offsets::Primitive::Properties + Offsets::Primitive::PropertyPosition,
            x,
            z);
    }

    return success;
}

bool step_horizontal_position(std::uint64_t primitive, const Vector3& horizontal_velocity, float dt, int repetitions)
{
    if (dt <= 0.0f || !g_Memory.IsValid(primitive))
        return false;

    repetitions = std::clamp(repetitions, 1, 100);
    const float step_dt = dt / static_cast<float>(repetitions);
    bool success = false;
    for (int i = 0; i < repetitions; ++i) {
        const Vector3 pos = g_Memory.Read<Vector3>(primitive + Offsets::Primitive::Position);
        const float next_x = pos.x + horizontal_velocity.x * step_dt;
        const float next_z = pos.z + horizontal_velocity.z * step_dt;
        success |= set_horizontal_position(primitive, next_x, next_z);
    }
    return success;
}

void walkspeed_loop()
{
    bool was_active = false;
    bool has_humanoid_backup = false;
    std::uint64_t backed_up_humanoid = 0;
    float backed_up_walkspeed = k_default_walkspeed;
    bool toggled = false;
    bool was_pressed = false;
    auto last_time = std::chrono::steady_clock::now();

    auto clear_backup = [&]() {
        has_humanoid_backup = false;
        backed_up_humanoid = 0;
        backed_up_walkspeed = k_default_walkspeed;
    };

    auto restore_humanoid_speed = [&]() {
        if (has_humanoid_backup && g_Memory.IsValid(backed_up_humanoid))
            set_humanoid_walkspeed(backed_up_humanoid, backed_up_walkspeed);
        clear_backup();
    };

    auto backup_humanoid_speed = [&](std::uint64_t humanoid) {
        if (!g_Memory.IsValid(humanoid))
            return;

        const bool humanoid_changed = !has_humanoid_backup || backed_up_humanoid != humanoid;
        if (!humanoid_changed)
            return;

        restore_humanoid_speed();
        backed_up_walkspeed = get_humanoid_walkspeed(humanoid).value_or(k_default_walkspeed);
        backed_up_humanoid = humanoid;
        has_humanoid_backup = true;
    };

    while (g_run.load()) {
        const auto now = std::chrono::steady_clock::now();
        float dt = std::chrono::duration<float>(now - last_time).count();
        if (dt < 0.0001f)
            dt = 0.0001f;
        last_time = now;

        const bool chat_focused = chat_is_focused();
        const bool allow_toggle = roblox_has_focus() && !chat_focused;

        if (!Cheat::g_Settings.misc.walkspeed) {
            toggled = false;
            was_pressed = false;
            if (was_active)
                restore_humanoid_speed();
            was_active = false;
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            continue;
        }

        bool key_on = false;
        if (allow_toggle || Cheat::g_Settings.misc.walkspeed_key == 0) {
            key_on = KeyActive(
                Cheat::g_Settings.misc.walkspeed_key,
                Cheat::g_Settings.misc.walkspeed_key_mode,
                toggled,
                was_pressed);
        } else if (chat_focused && Cheat::g_Settings.misc.walkspeed_key) {
            GetAsyncKeyState(Cheat::g_Settings.misc.walkspeed_key);
            key_on = false;
        }

        Cheat::g_Settings.misc.walkspeed_value =
            std::clamp(Cheat::g_Settings.misc.walkspeed_value, 1.0f, 500.0f);
        Cheat::g_Settings.misc.walkspeed_mode =
            std::clamp(Cheat::g_Settings.misc.walkspeed_mode, 0, 1);

        if (!key_on) {
            if (was_active)
                restore_humanoid_speed();
            was_active = false;
            std::this_thread::sleep_for(k_idle_sleep);
            continue;
        }

        std::uint64_t hrp = 0, prim = 0, humanoid = 0;
        const bool resolved = ResolveLocal(hrp, prim, humanoid);
        const auto mode = static_cast<walkspeed_mode_t>(Cheat::g_Settings.misc.walkspeed_mode);
        const float speed = Cheat::g_Settings.misc.walkspeed_value;
        const bool active = resolved;

        if (!active) {
            if (was_active)
                restore_humanoid_speed();
            was_active = false;
            std::this_thread::sleep_for(k_idle_sleep);
            continue;
        }

        backup_humanoid_speed(humanoid);

        if (mode == walkspeed_mode_t::humanoid) {
            set_humanoid_walkspeed(humanoid, speed);
        } else {
            set_humanoid_walkspeed(humanoid, k_walkspeed_controller_speed);

            Vector3 desired_velocity{};
            const bool has_direction = get_humanoid_move_velocity(humanoid, speed, desired_velocity);
            if (has_direction) {
                const float clamped_dt = std::clamp(dt, 0.001f, 0.05f);
                step_horizontal_position(prim, desired_velocity, clamped_dt, k_walkspeed_position_repetitions);
            }
        }

        was_active = true;
        std::this_thread::sleep_for(k_walkspeed_sleep);
    }

    restore_humanoid_speed();
}

}

void Cheat::Features::Speed::Start()
{
    if (g_run.load())
        return;
    g_run.store(true);
    g_thread = std::thread(walkspeed_loop);
}

void Cheat::Features::Speed::Stop()
{
    g_run.store(false);
    if (g_thread.joinable())
        g_thread.join();
}
