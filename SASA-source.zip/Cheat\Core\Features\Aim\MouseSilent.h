#pragma once
#include "../../Roblox/Math/Math.h"
#include <cstdint>

namespace Cheat {
namespace Features {
namespace MouseSilent {

    // Spoofs MouseService InputObject mouse position to world_target screen pos.
    void SetActive(bool on, const Vector3& world_target = {});
    void Restore();

    bool Aiming();

} // namespace MouseSilent
} // namespace Features
} // namespace Cheat
