#pragma once
#include "../../Roblox/Math/Math.h"

namespace Cheat {
namespace Features {
namespace ViewportSilent {

void SetActive(bool on, const Vector3& world_target = {});
void Restore();
void Shutdown();
bool Aiming();

} // namespace ViewportSilent
} // namespace Features
} // namespace Cheat
