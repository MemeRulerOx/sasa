#include "Fly.h"

#include "../../Globals/Globals.h"
#include "../../Memory/Memory.h"
#include "../../Roblox/Engine/Offsets/Offsets.h"
#include "../../Roblox/Engine/Classes/Classes.h"
#include "../../../Renderer/Renderer.h"
#include "../../../Settings.h"

#include <Windows.h>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <mutex>
#include <thread>
#include <algorithm>

#undef GetClassName

namespace {

using clock = std::chrono::steady_clock;

std::atomic<bool> fly_running{ false };
std::atomic<bool> fly_gravity_running{ false };
std::atomic<bool> fly_active_state{ false };
std::thread fly_worker;
std::thread fly_gravity_worker;

constexpr auto k_idle_sleep   = std::chrono::milliseconds(8);
constexpr auto k_off_sleep    = std::chrono::milliseconds(50);
constexpr auto k_active_sleep = std::chrono::milliseconds(1);

struct float3x3
{
    float _11, _12, _13;
    float _21, _22, _23;
    float _31, _32, _33;
};

using NtWriteVirtualMemory_t = LONG(__stdcall*)(HANDLE, PVOID, PVOID, ULONG, PULONG);
using NtReadVirtualMemory_t  = LONG(__stdcall*)(HANDLE, PVOID, PVOID, ULONG, PULONG);

NtWriteVirtualMemory_t nt_write = nullptr;
NtReadVirtualMemory_t  nt_read  = nullptr;

void ensure_nt_apis()
{
    static std::once_flag once;
    std::call_once(once, []() {
        HMODULE ntdll = ::GetModuleHandleW(L"ntdll.dll");
        if (!ntdll)
            ntdll = ::LoadLibraryW(L"ntdll.dll");
        if (!ntdll)
            return;
        nt_write = reinterpret_cast<NtWriteVirtualMemory_t>(::GetProcAddress(ntdll, "NtWriteVirtualMemory"));
        nt_read  = reinterpret_cast<NtReadVirtualMemory_t>(::GetProcAddress(ntdll, "NtReadVirtualMemory"));
    });
}

bool fast_write(std::uint64_t address, const void* buffer, std::size_t size)
{
    ensure_nt_apis();
    HANDLE process = g_Memory.GetHandle();
    if (!process || !address || !buffer || !size)
        return false;

    if (nt_write) {
        const LONG status = nt_write(
            process,
            reinterpret_cast<PVOID>(address),
            const_cast<void*>(buffer),
            static_cast<ULONG>(size),
            nullptr);
        if (status >= 0)
            return true;
    }

    SIZE_T written = 0;
    return ::WriteProcessMemory(
        process,
        reinterpret_cast<PVOID>(address),
        buffer,
        size,
        &written) != 0 && written == size;
}

bool fast_read(std::uint64_t address, void* buffer, std::size_t size)
{
    ensure_nt_apis();
    HANDLE process = g_Memory.GetHandle();
    if (!process || !address || !buffer || !size)
        return false;

    if (nt_read) {
        const LONG status = nt_read(
            process,
            reinterpret_cast<PVOID>(address),
            buffer,
            static_cast<ULONG>(size),
            nullptr);
        if (status >= 0)
            return true;
    }

    SIZE_T read = 0;
    return ::ReadProcessMemory(
        process,
        reinterpret_cast<LPCVOID>(address),
        buffer,
        size,
        &read) != 0 && read == size;
}

template <typename T>
bool fast_write_t(std::uint64_t address, const T& value)
{
    return fast_write(address, &value, sizeof(T));
}

template <typename T>
T fast_read_t(std::uint64_t address)
{
    T value{};
    fast_read(address, &value, sizeof(T));
    return value;
}

enum class keyboard_layout_t
{
    qwerty,
    azerty
};

keyboard_layout_t get_keyboard_layout(HWND reference_window)
{
    DWORD thread_id = 0;
    if (reference_window)
        thread_id = GetWindowThreadProcessId(reference_window, nullptr);

    const HKL layout = GetKeyboardLayout(thread_id);
    const LANGID lang_id = LOWORD(reinterpret_cast<UINT_PTR>(layout));
    if (PRIMARYLANGID(lang_id) == LANG_FRENCH)
        return keyboard_layout_t::azerty;

    return keyboard_layout_t::qwerty;
}

bool roblox_has_focus()
{
    const HWND window = Cheat::Renderer::GetGameHwnd();
    return window && ::IsWindow(window) && ::GetForegroundWindow() == window;
}

Vector3 get_forward(const float3x3& rot)
{
    Vector3 forward(-rot._13, -rot._23, -rot._33);
    const float len_sq = forward.LengthSquared();
    if (len_sq < 1e-4f || !std::isfinite(len_sq))
        return Vector3(0.0f, 0.0f, -1.0f);
    forward.Normalize();
    return forward;
}

Vector3 get_right(const float3x3& rot)
{
    Vector3 right(-rot._11, rot._21, -rot._31);
    const float len_sq = right.LengthSquared();
    if (len_sq < 1e-4f || !std::isfinite(len_sq))
        return Vector3(1.0f, 0.0f, 0.0f);
    right.Normalize();
    return right;
}

bool KeyActive(int key, int mode, bool& toggled, bool& was_pressed)
{
    if (key == 0)
        return true;

    const bool pressed = (GetAsyncKeyState(key) & 0x8000) != 0;
    if (mode == 1) {
        if (pressed && !was_pressed)
            toggled = !toggled;
        was_pressed = pressed;
        return toggled;
    }

    was_pressed = pressed;
    return pressed;
}

bool set_linear_velocity(std::uint64_t primitive, const Vector3& velocity)
{
    if (!primitive)
        return false;

    fast_write_t(primitive + Offsets::Primitive::AssemblyLinearVelocity, velocity);
    const Vector3 zero{};
    fast_write_t(primitive + Offsets::Primitive::AssemblyAngularVelocity, zero);
    return true;
}

bool clear_velocity(std::uint64_t primitive)
{
    const Vector3 zero{};
    return set_linear_velocity(primitive, zero);
}

struct local_fly_snap
{
    std::uint64_t address = 0;
    std::uint64_t hrp = 0;
    std::uint64_t primitive = 0;
    std::uint64_t camera = 0;
};

local_fly_snap resolve_local_snap()
{
    local_fly_snap snap{};

    if (!Cheat::Globals::Players || !Cheat::Globals::Players->address)
        return snap;

    const std::uint64_t local = fast_read_t<std::uint64_t>(
        Cheat::Globals::Players->address + Offsets::Player::LocalPlayer);
    if (!local)
        return snap;

    const std::uint64_t character = fast_read_t<std::uint64_t>(
        local + Offsets::Player::ModelInstance);
    if (!character)
        return snap;

    snap.address = local;

    const auto humanoid = Cheat::Instance(character).FindFirstChild("Humanoid");
    if (humanoid && humanoid->address) {
        snap.hrp = Cheat::Humanoid(humanoid->address).GetRootPartAddress();
    }
    if (!snap.hrp) {
        const auto hrp = Cheat::Instance(character).FindFirstChild("HumanoidRootPart");
        if (hrp)
            snap.hrp = hrp->address;
    }

    if (snap.hrp)
        snap.primitive = fast_read_t<std::uint64_t>(snap.hrp + Offsets::BasePart::Primitive);

    if (Cheat::Globals::Workspace && Cheat::Globals::Workspace->address) {
        snap.camera = fast_read_t<std::uint64_t>(
            Cheat::Globals::Workspace->address + Offsets::Workspace::CurrentCamera);
    }

    return snap;
}

void refresh_snap_pointers(local_fly_snap& snap)
{
    if (snap.hrp)
        snap.primitive = fast_read_t<std::uint64_t>(snap.hrp + Offsets::BasePart::Primitive);

    if (Cheat::Globals::Workspace && Cheat::Globals::Workspace->address) {
        snap.camera = fast_read_t<std::uint64_t>(
            Cheat::Globals::Workspace->address + Offsets::Workspace::CurrentCamera);
    }
}

void fly_loop()
{
    bool was_active = false;
    Vector3 current_velocity{};

    bool toggled = false;
    bool was_pressed = false;

    local_fly_snap cached{};
    auto last_resolve = clock::now() - std::chrono::seconds(1);

    while (fly_running.load(std::memory_order_relaxed)) {
        const auto now = clock::now();

        if (!Cheat::g_Settings.misc.fly) {
            toggled = false;
            was_pressed = false;
            if (was_active && cached.primitive) {
                clear_velocity(cached.primitive);
                current_velocity = {};
            }
            fly_active_state.store(false, std::memory_order_relaxed);
            was_active = false;
            std::this_thread::sleep_for(k_off_sleep);
            continue;
        }

        const bool roblox_active = roblox_has_focus();
        const bool allow_toggle = roblox_active || Cheat::g_Settings.misc.fly_key == 0;

        bool key_on = false;
        if (allow_toggle) {
            key_on = KeyActive(
                Cheat::g_Settings.misc.fly_key,
                Cheat::g_Settings.misc.fly_key_mode,
                toggled,
                was_pressed);
        }

        if (!cached.hrp || !cached.camera) {
            if ((now - last_resolve) > std::chrono::milliseconds(50)) {
                cached = resolve_local_snap();
                last_resolve = now;
            }
        } else if ((now - last_resolve) > std::chrono::milliseconds(250)) {
            refresh_snap_pointers(cached);
            last_resolve = now;
        }

        const bool fly_active = Cheat::g_Settings.misc.fly && key_on;
        const bool sleep_when_idle = !fly_active;
        fly_active_state.store(fly_active, std::memory_order_relaxed);

        if (cached.address == 0 || !cached.primitive || !cached.camera) {
            if (was_active && cached.primitive) {
                clear_velocity(cached.primitive);
                current_velocity = {};
            }

            fly_active_state.store(false, std::memory_order_relaxed);
            was_active = false;

            if (sleep_when_idle)
                std::this_thread::sleep_for(k_idle_sleep);
            continue;
        }

        float3x3 rotation{};
        if (!fast_read(cached.camera + Offsets::Camera::Rotation, &rotation, sizeof(rotation))) {
            if (was_active && cached.primitive) {
                clear_velocity(cached.primitive);
                current_velocity = {};
            }
            fly_active_state.store(false, std::memory_order_relaxed);
            was_active = false;
            if (sleep_when_idle)
                std::this_thread::sleep_for(k_idle_sleep);
            continue;
        }

        Vector3 forward = get_forward(rotation);
        Vector3 right = get_right(rotation);
        const Vector3 world_up(0.0f, 1.0f, 0.0f);

        if (!fly_active) {
            if (was_active) {
                clear_velocity(cached.primitive);
                current_velocity = {};
            }

            was_active = false;

            if (sleep_when_idle)
                std::this_thread::sleep_for(k_idle_sleep);
            continue;
        }

        was_active = true;

        const keyboard_layout_t layout = get_keyboard_layout(Cheat::Renderer::GetGameHwnd());
        const int forward_key = layout == keyboard_layout_t::azerty ? 'Z' : 'W';
        const int left_key = layout == keyboard_layout_t::azerty ? 'Q' : 'A';

        auto key_down = [](int vk) -> bool {
            return (GetAsyncKeyState(vk) & 0x8000) != 0;
        };

        if (forward.LengthSquared() < 1e-6f || right.LengthSquared() < 1e-6f) {
            forward = Vector3(0.0f, 0.0f, 1.0f);
            right = Vector3(1.0f, 0.0f, 0.0f);
        } else {
            forward.Normalize();
            right.Normalize();
        }

        Vector3 target_velocity{};
        const float speed = (std::max)(Cheat::g_Settings.misc.fly_speed, 0.0f);

        if (roblox_active || Cheat::g_Settings.misc.fly_key == 0) {
            if (key_down(forward_key)) target_velocity += forward * speed;
            if (key_down('S'))         target_velocity -= forward * speed;
            if (key_down(left_key))    target_velocity += right * speed;
            if (key_down('D'))         target_velocity -= right * speed;

            float vertical_input = 0.0f;
            if (key_down(VK_SPACE)) vertical_input += 1.0f;
            if (key_down(VK_CONTROL)) vertical_input -= 1.0f;
            if (std::abs(vertical_input) > 0.0f)
                target_velocity += world_up * (vertical_input * speed);
        }

        current_velocity = target_velocity;
        set_linear_velocity(cached.primitive, current_velocity);
        std::this_thread::sleep_for(k_active_sleep);
    }

    {
        const auto snap = resolve_local_snap();
        if (snap.address != 0 && snap.primitive)
            clear_velocity(snap.primitive);
    }
    fly_active_state.store(false, std::memory_order_relaxed);
}

void fly_gravity_loop()
{
    bool gravity_overridden = false;
    float gravity_backup = 0.0f;

    while (fly_gravity_running.load(std::memory_order_relaxed)) {
        if (!Cheat::g_Settings.misc.fly) {
            if (gravity_overridden &&
                Cheat::Globals::Workspace &&
                Cheat::Globals::Workspace->address) {
                const auto world = fast_read_t<std::uint64_t>(
                    Cheat::Globals::Workspace->address + Offsets::Workspace::World);
                if (world)
                    fast_write_t(world + Offsets::World::Gravity, gravity_backup);
                gravity_overridden = false;
            }
            std::this_thread::sleep_for(k_off_sleep);
            continue;
        }

        const bool fly_active = fly_active_state.load(std::memory_order_relaxed);
        const bool can_write_gravity =
            Cheat::Globals::Workspace &&
            Cheat::Globals::Workspace->address;

        if (fly_active && can_write_gravity) {
            const auto world = fast_read_t<std::uint64_t>(
                Cheat::Globals::Workspace->address + Offsets::Workspace::World);
            if (world) {
                if (!gravity_overridden) {
                    gravity_backup = fast_read_t<float>(world + Offsets::World::Gravity);
                    gravity_overridden = true;
                }
                const float zero = 0.0f;
                fast_write_t(world + Offsets::World::Gravity, zero);
            }
        } else if (!fly_active && gravity_overridden && can_write_gravity) {
            const auto world = fast_read_t<std::uint64_t>(
                Cheat::Globals::Workspace->address + Offsets::Workspace::World);
            if (world)
                fast_write_t(world + Offsets::World::Gravity, gravity_backup);
            gravity_overridden = false;
        }

        std::this_thread::sleep_for(fly_active ? k_active_sleep : k_idle_sleep);
    }

    if (gravity_overridden &&
        Cheat::Globals::Workspace &&
        Cheat::Globals::Workspace->address) {
        const auto world = fast_read_t<std::uint64_t>(
            Cheat::Globals::Workspace->address + Offsets::Workspace::World);
        if (world)
            fast_write_t(world + Offsets::World::Gravity, gravity_backup);
    }
}

}

void Cheat::Features::Fly::Start()
{
    if (!fly_running.load(std::memory_order_relaxed)) {
        fly_running = true;
        fly_worker = std::thread(fly_loop);
    }

    if (!fly_gravity_running.load(std::memory_order_relaxed)) {
        fly_gravity_running = true;
        fly_gravity_worker = std::thread(fly_gravity_loop);
    }
}

void Cheat::Features::Fly::Stop()
{
    fly_running.store(false, std::memory_order_relaxed);
    fly_gravity_running.store(false, std::memory_order_relaxed);
    if (fly_worker.joinable())
        fly_worker.join();
    if (fly_gravity_worker.joinable())
        fly_gravity_worker.join();
}
